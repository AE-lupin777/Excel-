# Make-CtcTestDataEx.ps1 取扱説明書

- 対象：`Make-CtcTestDataEx.ps1`
- 文書作成日：2026年10月31日
- 用途：CTC Sender（ULAgent）のログ取込・登録試験用データの作成
- 動作環境：Windows PowerShell 5.1 / PowerShell 7 系（Windowsでの使用を想定）

## 1. 概要

本ツールは、CTCのSender（ULAgent）が監視する入力フォルダに、**EVENT・SAMPLING・PROCESSの3種類の試験用ファイルを各1個**作成するPowerShellスクリプトです。特定種類のみの生成もできます。

主な用途は、各ログ種類のファイル検出・転送・登録の確認、および継続運転試験での試験ファイル投入です。**本ツール自体はファイルを生成・配置するだけで、Senderの起動や転送処理は実行しません。**

| 種類 | 拡張子 | 内容 |
|---|---|---|
| EVENT | `.evt` | 1行1JSONのイベント記録 |
| SAMPLING | `.csv` | 日時・測定値8項目のサンプリング記録 |
| PROCESS | `.log` | ロット・ウェハ・チャンバー・工程・測定値のJSON |

## 2. 重要事項：大量生成版ツール（Ex_24H）との違い

| 比較項目 | `Make-CtcTestDataEx.ps1`（本ツール） | `Make-CtcTestDataEx_24H.ps1` |
|---|---|---|
| 主目的 | Sender取込確認用の少数ファイル投入 | 時間帯別に多数のファイルを生成 |
| 標準生成数 | 3種類各1ファイル、計3ファイル | 145枠×3種類＝435ファイル |
| 日付指定 | なし。実行時刻を使用 | `-Date`指定あり |
| 件数指定 | なし | `-Count`指定あり |
| サイズ指定 | 全種類共通の`-TargetSize` | 種類別に指定可能 |
| 既存出力先 | フォルダを全削除しない | 出力先を削除して再構築 |
| 出力先既定値 | スクリプト配置先の`output` | スクリプト配置先の`output` |

**注意：** 本ツールは出力先フォルダを一括削除しませんが、**同じファイル名が既に存在する場合はそのファイルを上書きします**。また、Senderの監視先を指定すると、Senderがファイルを読み込み、移動・削除などを行う可能性があります（挙動はSenderの設定に依存します）。

## 3. 準備と実行手順

1. `Make-CtcTestDataEx.ps1`を任意の作業フォルダに保存します。
2. PowerShellを起動し、スクリプトのフォルダに移動します。
3. 最初はSenderの監視先**以外**に出力してファイル内容を確認します。
4. Senderへの投入試験を行う場合、監視対象のデータルートを`-Root`で指定します。

### 3.1 既定値で3種類を生成

```powershell
Set-Location '\TestFileCreate'
.\Make-CtcTestDataEx.ps1
```

既定値の場合は、スクリプトと同じ場所にある`output`配下に各種類1ファイルずつ生成します。

### 3.2 Senderの入力フォルダへ投入

```powershell
.\Make-CtcTestDataEx.ps1 -Root 'C:\CTC-Main\ULAgent'
```

**必ず実際のSender設定とルートパスを確認してから実行してください。** ソース内のヘルプには`C:\CTC-Main\ULAgent`が例示されていますが、実装上の既定値ではありません。

### 3.3 EVENTのみ投入

```powershell
.\Make-CtcTestDataEx.ps1 -Root 'C:\CTC-Main\ULAgent' -Kinds EVENT
```

### 3.4 SAMPLINGとPROCESSのみ投入

```powershell
.\Make-CtcTestDataEx.ps1 -Root 'C:\CTC-Main\ULAgent' -Kinds SAMPLING,PROCESS
```

### 3.5 最小ファイルサイズを指定

```powershell
.\Make-CtcTestDataEx.ps1 -Root '.\output_trial' -TargetSize '28.1KB'
```

`-TargetSize`は選択された**全ログ種類に共通**です。ファイルの種類ごとに異なるサイズを指定するパラメータはありません。

### 3.6 イベント接続名・チャンバー名を変更

```powershell
.\Make-CtcTestDataEx.ps1 `
    -Root '.\output_trial' `
    -Kinds EVENT,SAMPLING `
    -EventConnection 'PMC' `
    -SamplingChamber 'Chamber-A'
```

## 4. パラメータ一覧

| パラメータ | 既定値 | 説明 |
|---|---|---|
| `-Root` | スクリプト配置先の`output` | ファイルの出力先ルート。**指定先はSender監視フォルダとなり得る** |
| `-Kinds` | `EVENT,SAMPLING,PROCESS` | 生成対象。1種類または複数種類を選択 |
| `-EventConnection` | `PMC` | EVENTのサブフォルダ名とログ内`Source`値 |
| `-SamplingChamber` | `Chamber-A` | SAMPLINGのサブフォルダ名 |
| `-TargetSize` | 空（未指定） | 選択したファイルに共通の目標最小サイズ |

`-Kinds`は`EVENT`、`SAMPLING`、`PROCESS`のいずれかのみ受け付けます。種類指定を省略すると3種類すべてを生成します。

### サイズの書式

`-TargetSize`は以下のように指定できます。

```powershell
-TargetSize '10KB'
-TargetSize '28.1KB'
-TargetSize '5MB'
-TargetSize '1G'
```

利用可能な単位は`K`、`KB`、`M`、`MB`、`G`、`GB`です。単位なしの数値、`KiB`などは受け付けません。換算は`1KB = 1024バイト`、`1MB = 1024KB`、`1GB = 1024MB`です。未指定の場合はログ種類ごとの最小件数で生成します。

## 5. 出力ファイルとファイル名

実行日時を例として**2026年10月31日 18:22:35**とした場合、生成パスは以下のとおりです。

```text
output\
├─ EventLog\
│  └─ PMC\
│     └─ 20261031_16.evt
├─ SamplingLog\
│  └─ Chamber-A\
│     └─ 20261031_1820.csv
└─ ProcessLog\
   └─ 20261031_182235.log
```

ファイル名は以下のルールです。

| 種類 | パス・ファイル名 | ファイル名に用いる日時 |
|---|---|---|
| EVENT | `EventLog\<接続名>\yyyyMMdd_HH.evt` | **実行時刻の2時間前**（時単位） |
| SAMPLING | `SamplingLog\<チャンバー名>\yyyyMMdd_HHmm.csv` | **実行時刻の2分前**（分単位） |
| PROCESS | `ProcessLog\yyyyMMdd_HHmmss.log` | **実行時刻**（秒単位） |

**重要：** ファイル名の日時とファイル内の日時は必ずしも一致しません。EVENT・SAMPLINGの本文日時は`$now`（実行時刻）を基準として生成されます。これはSender側のファイル名要件に合わせて衝突を避けるための処理です。

特にEVENTは**1時間単位のファイル名**です。同じ時間帯に繰り返し実行すると同じファイル名になり、既存のEVENTファイルが上書きされます。SAMPLINGも同じ分内、PROCESSも同じ秒内の再実行で上書きの可能性があります。

## 6. 各ログの仕様

### 6.1 EVENT（`.evt`）

- 形式：UTF-8（BOMなし）、1行1JSON、CRLF改行
- 最小件数：2レコード
- 主な項目：`Time`、`Source`、`LogType`、`Severity`、`Message`、`MetaData.WaferID`
- `Severity`は`Info`と`Warn`が交互
- `Message`は`Test start`と`Running`が交互
- `Time`は実行時刻から1秒ずつ増加

例（構造例）：

```json
{"Time":"2026-10-31 18:22:35.0000","Source":"PMC","LogType":"Log","Severity":"Info","Message":"Test start","MetaData":{"WaferID":"WF-0000001"}}
```

### 6.2 SAMPLING（`.csv`）

- 形式：CSV、UTF-8（BOMなし）
- 1行目：ヘッダー、2行目：単位、3行目以降：データ
- 測定項目：`Data01`～`Data08`
- 単位：`degC`、`V`、`Pa`の繰り返し
- 最小データ行数：20行
- データの時刻：実行時刻から100ミリ秒間隔
- 値は小数3桁の計算値（実測値ではない）

先頭2行は以下のとおりです。

```csv
Date,Time,Data01,Data02,Data03,Data04,Data05,Data06,Data07,Data08
,,degC,V,Pa,degC,V,Pa,degC,V
```

### 6.3 PROCESS（`.log`）

- 形式：ファイル全体で1つのJSONオブジェクト、UTF-8（BOMなし）
- 最小構成：1ウェハ、1チャンバー、1ステップ、10測定データ
- 主な最上位項目：`ControlJobID`、`CarrierID`、`LotID`、`FlowRecipe`、`StartTime`、`EndTime`、`Wafers`
- ウェハ内の項目：`LocalID`、`WaferID`、`ProcessJobID`、`TransferRoute`、`StartTime`、`EndTime`、`ChamberDatas`
- チャンバー内の項目：`Chamber`、`RecipeName`、`Steps`
- ステップ内の項目：`StepNo`、`OriginalStepNo`、`RepeatStepCount`、`Datas`
- 測定値：`Pressure`（単位`Pa`）、各ウェハ10点

`-TargetSize`を指定すると、ウェハのJSONを追加してサイズを増やします。

**サイズ判定上の注意：** PROCESSは**ウェハ部分のJSONサイズの合計**を目標値と比較します。最上位のJSONフィールド・配列・装飾部分は判定に含まれません。したがって完成ファイルは指定サイズより大きくなることがあります。

## 7. サイズ・生成件数の仕様

| 種類 | サイズ未指定時 | サイズ指定時 |
|---|---|---|
| EVENT | 2レコード | 指定バイト数以上までレコードを追加 |
| SAMPLING | 20データ行＋ヘッダー・単位行 | 指定バイト数以上までデータ行を追加 |
| PROCESS | 1ウェハ（10測定データ） | ウェハJSONの累積サイズが指定値以上になるまで追加 |

ファイルサイズは「**指定値ちょうど**」ではなく「**指定した下限を満たす**」という扱いです。レコードを途中で切らないため、超過分が発生します。

`28.1KB`は約**28,774バイト**です（`28.1×1024=28,774.4`）。例えば29,573バイトなら、その下限を満たしています。

### サイズと個数の確認例

```powershell
$root = '.\output_trial'
$files = @(Get-ChildItem -LiteralPath $root -Recurse -File)
"Files: $($files.Count)"
$files | Select-Object FullName, Length
```

サイズ28.1KB以上を確認：

```powershell
$minimum = [long](28.1 * 1KB)
$files | Where-Object { $_.Length -lt $minimum } |
    Select-Object FullName,Length
```

**注意：** 最小構成では目標サイズを指定していないため、この確認は`-TargetSize 28.1KB`で生成した場合にのみ適用してください。

## 8. Senderでの取込・転送結果確認

スクリプトの最後に次の内容が表示されます。

```text
Done. Sender picks up files on its scan interval (default 60s).
Check Sender: Invoke-RestMethod 'http://127.0.0.1:5080/api/transfers?limit=10' | ConvertTo-Json -Depth 5
```

このメッセージは**生成処理が完了したことを示すもの**であり、Senderがファイルを正常に取り込んだことを保証しません。

ソース内には、Senderの監視周期が**既定60秒**である旨が記載されています。ただし実際の設定値はSender側で確認してください。

Senderの転送履歴を確認する例：

```powershell
Invoke-RestMethod 'http://127.0.0.1:5080/api/transfers?limit=10' |
    ConvertTo-Json -Depth 5
```

これは**対象PC上の `127.0.0.1:5080` にAPIが存在して起動している場合のみ**実行できます。接続不可の場合は、Senderサービスの起動状態、待受ポート、設定を確認してください。APIによる応答内容はSenderの実装に依存します。

## 9. 動作確認の推奨手順

1. まず監視外フォルダに投入：
   ```powershell
   .\Make-CtcTestDataEx.ps1 -Root '.\output_trial'
   ```
2. `output_trial`に3種類各1ファイルが作られたことを確認。
3. EVENTの各行がJSONであること、SAMPLINGのCSVヘッダー・測定行、PROCESSのJSON構文を確認。
4. 必要なら`-TargetSize '28.1KB'`等を指定してサイズ検証。
5. 実際のSender設定に合うルートと接続名・チャンバー名を確認。
6. 監視先を指定して1種類ずつ試験投入。
7. Senderのログまたは転送履歴APIで取込・転送・登録結果を確認。

JSON構文確認例：

```powershell
# 例：適切な実際のファイル名に置き換える
Get-Content '.\output_trial\ProcessLog\20261031_182235.log' -Raw |
    ConvertFrom-Json | Out-Null
```

EVENTが複数行の場合：

```powershell
Get-Content '.\output_trial\EventLog\PMC\20261031_16.evt' |
    ForEach-Object { $_ | ConvertFrom-Json | Out-Null }
```

## 10. 注意事項・トラブルシューティング

| 事象 | 確認事項・対応 |
|---|---|
| ファイルを作成できない | 出力先パス、書込権限、ファイル使用状況を確認 |
| 指定サイズでエラー | `-TargetSize`が`10KB`など対応形式か確認 |
| ファイルが3個より少ない | `-Kinds`の指定、および生成後にSenderが取得・移動した可能性を確認 |
| Senderに取り込まれない | `-Root`、Senderの監視設定、接続名・チャンバー名、ファイル名形式を照合 |
| 同名ファイルの上書き | EVENTは同じ時間帯、SAMPLINGは同じ分、PROCESSは同じ秒の実行に注意 |
| ファイル名と本文の時間が違う | EVENTは2時間前、SAMPLINGは2分前のファイル名を使用する仕様 |
| 転送履歴APIへ接続できない | Senderの起動状態、APIの有効化、ポート5080、実行PCを確認 |
| サイズが指定値と一致しない | 指定値は固定長ではなく下限。PROCESSはウェハ部分のみを閾値判定 |

### 重要な運用上の注意

- **監視先への出力は実際のシステム処理を起動させる可能性があります。** 稼働環境への投入は承認・実施条件を確認してください。
- スクリプトは**生成ファイルを削除する処理を持ちません**。不要な試験ファイルの整理は運用側で行ってください。
- 同一名に対しては`WriteAllText`で**上書き**します。
- 各ログに設定した日時・測定値・IDは試験用のデータです。実機データとの完全互換を保証するものではありません。
- コードはWindows PowerShell 5.1の文字コード問題を避けるため、コメント・表示メッセージにASCIIを使用しています。
- PROCESS内の終了時刻は各ウェハの増加に応じて見直されないため、ウェハが多数追加された場合、**ロットの終了時刻より後のウェハ・工程時刻が含まれる可能性**があります。日時整合性を検証する試験に使う場合は注意してください。

---

## 11. まとめ

`Make-CtcTestDataEx.ps1`は、**Senderの監視対象フォルダに、ログ種類ごとに少数の試験データを投入するツール**です。大量生成版ツールのEx_24Hとは異なり、実行時刻を使って各種類1ファイルを作るため、取込・登録経路の個別確認に向いています。サイズを揃えたい場合は`-TargetSize`、種類を選びたい場合は`-Kinds`、監視先を切り替えたい場合は`-Root`を使います。

*本書は添付された `Make-CtcTestDataEx.ps1` の実装を参照して作成しました。*

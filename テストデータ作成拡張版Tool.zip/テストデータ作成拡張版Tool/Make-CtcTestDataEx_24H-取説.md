# Make-CtcTestDataEx_24H.ps1 取扱説明書

- 対象スクリプト：`Make-CtcTestDataEx_24H.ps1`
- 対象環境：Windows PowerShell 5.1 以降（PowerShell 7でも利用可能な構文）
- 文書作成日：2026-10-31
- 用途：CTC関連のテスト用ログデータ生成

## 1. 概要

本ツールは、指定日を起点に**10分間隔**の試験用データを生成するPowerShellスクリプトです。ログの取込・転送・解析・性能試験などで利用するダミーデータを生成します。24時間連続稼働確認等の長時間用テストファイル作成に使用します。実運用装置から収集したログではなくシミュレートして生成したファイルです。

生成対象は以下の3種類です。

| 種類 | ファイル拡張子 | 内容 |
|---|---|---|
| EVENT | `.evt` | 1行に1つのJSONオブジェクトを記録するイベントログ |
| SAMPLING | `.csv` | 8項目の測定値を含むサンプリングログ |
| PROCESS | `.log` | ロット、ジョブ、ウェハ、チャンバー、工程・測定値を含むJSONログ |

既定では145時間枠（指定日の00:00から翌日00:00までを10分刻み）について各種類1ファイル、**合計435ファイル**を生成します。

> **重要：出力先の既存データは削除されます。**
> スクリプトは処理開始時に指定された出力先フォルダを再帰的に削除し、作り直します。保存が必要なファイルは出力先に置かないでください。

## 2. 実行準備

1. `Make-CtcTestDataEx_24H.ps1` を任意の作業フォルダに配置します。
2. PowerShellを起動し、そのフォルダに移動します。
3. 出力先の空き容量と、そこに既存データがないことを確認します。
4. 必要なパラメータを指定して実行します。

例：`\TestFileCreate` に配置した場合

```powershell
Set-Location '\TestFileCreate'
& '.\Make-CtcTestDataEx_24H.ps1'
```

ファイル名に括弧 `()` があるため、上記のように**引用符と呼び出し演算子 `&`** を用いることを推奨します。

実行ポリシーによりスクリプトが拒否される場合は、社内ルールに従って実行環境を確認してください。ポリシーの恒久変更は不要です。

## 3. パラメータ一覧

| パラメータ | 型 | 既定値 | 説明 |
|---|---|---|---|
| `-Date` | string | 実行日（`yyyyMMdd`） | 出力データの基準日。存在する日付を指定 |
| `-Count` | int | `145` | 生成する10分枠の数。許容値1～100000 |
| `-OutputRoot` | string | スクリプト配置フォルダ直下の`output` | 出力先フォルダ。**既存内容は削除** |
| `-Root` | string | 同上 | `-OutputRoot`の別名 |
| `-Kinds` | string[] | `EVENT,SAMPLING,PROCESS` | 作成するログ種類。指定可能値は3種類 |
| `-EventConnection` | string | `PMC` | EVENTの接続名（フォルダ名およびJSONの`Source`に使用） |
| `-SamplingChamber` | string | `Chamber_24h` | SAMPLINGの出力フォルダ名 |
| `-EventSize` | string | 空文字 | EVENTファイルの最小目標サイズ |
| `-SamplingSize` | string | 空文字 | SAMPLINGファイルの最小目標サイズ |
| `-ProcessSize` | string | 空文字 | PROCESSファイルの最小目標サイズ |

サイズの書式は `500KB`、`28.1KB`、`10MB`、`1GB` などです。`K`、`M`、`G` も指定できます。**単位なしのバイト数や `KiB` は受け付けません。** サイズ未指定の場合は、ログごとの最低件数で生成します。

PowerShellでの換算基準は `1KB = 1024バイト`、`1MB = 1024KB`、`1GB = 1024MB` です。

## 4. 実行例

### 4.1 既定値で全種類を生成

```powershell
& '.\Make-CtcTestDataEx_24H.ps1'
```

当日の日付で145枠、合計435ファイルを作成します。

### 4.2 日付と枠数を指定

```powershell
& '.\Make-CtcTestDataEx_24H.ps1' -Date 20261031 -Count 145
```

### 4.3 ログごとに目標サイズを指定

```powershell
& '.\Make-CtcTestDataEx_24H.ps1' `
    -Date 20261031 `
    -Count 145 `
    -EventSize 552KB `
    -SamplingSize 2141KB `
    -ProcessSize 28.1KB
```

指定した最小サイズに達するまでレコードまたはウェハ情報を増やします。ファイルサイズは厳密な一致にはなりません。

### 4.4 PROCESSのみを生成

```powershell
& '.\Make-CtcTestDataEx_24H.ps1' `
    -Date 20261031 `
    -Count 145 `
    -Kinds PROCESS `
    -ProcessSize 28.1KB
```

### 4.5 複数種類を選択し、出力先を変更

```powershell
& '.\Make-CtcTestDataEx_24H.ps1' `
    -Date 20261031 `
    -Kinds EVENT,SAMPLING `
    -OutputRoot '\CTC_TestOutput'
```

**注意：`\CTC_TestOutput` が既に存在すると、その中身はすべて削除されます。**

### 4.6 少量で事前確認

```powershell
& '.\Make-CtcTestDataEx_24H.ps1' `
    -Date 20261031 `
    -Count 3 `
    -OutputRoot '.\output_trial'
```

上記では3枠×3種類＝9ファイルを作成します。

## 5. 出力フォルダ・ファイル名

以下は`-Date 20261031 -Count 145`で実行した場合の例です。

```text
output\
  n00-0\
    EventLog\
      PMC_00\
        20261031_00.evt
    SamplingLog\
      Chamber_24h\
        20261031_0000.csv
    ProcessLog\
      20261031_000000.log
  n00-1\
    EventLog\PMC_00\20261031_01.evt
    SamplingLog\Chamber_24h\20261031_0010.csv
    ProcessLog\20261031_001000.log
  ...
  n23-5\
    EventLog\PMC_23\20261031_05.evt
    SamplingLog\Chamber_24h\20261031_2350.csv
    ProcessLog\20261031_235000.log
  n24-0\
    EventLog\PMC_24\20261031_00.evt
    SamplingLog\Chamber_24h\20261031_2400.csv
    ProcessLog\20261031_240000.log
```

- `nHH-I`：開始時刻に対応するルール上の時（`HH`）と10分位置（`I`=0～5）。
- EVENT：`EventLog\<接続名>_HH\yyyyMMdd_II.evt`
- SAMPLING：`SamplingLog\<チャンバー名>\yyyyMMdd_HHmm.csv`
- PROCESS：`ProcessLog\yyyyMMdd_HHmm00.log`

**翌日00:00枠の注意点：** 最後の`n24-0`は内部のログ日時では翌日00:00ですが、**ファイル名には基準日の`20261031`と時刻`24`**が使われます。通常の日付時刻表記と異なるため、受け側の取込ルールを確認してください。

### 生成数

- `Count = 145`：145枠×3種類＝**435ファイル**
- `Count = 3`：3枠×3種類＝**9ファイル**
- `Kinds = PROCESS`、`Count = 145`：**145ファイル**

出力先直下の時間枠フォルダ数は、通常`Count`と等しくなります。ただし`Count`を非常に大きくすると日をまたぎ、フォルダ名が`n24-0`、`n25-0`のように増えていきます。

## 6. 各ログの内容

### 6.1 EVENT

1行1レコードの圧縮JSON（JSON Lines形式）です。

代表的なフィールド：

`Time`、`Source`、`LogType`、`Severity`、`Message`、`MetaData.WaferID`

`Severity`は`Info`と`Warn`、`Message`は`Test start`と`Running`が交互に生成されます。**最小2レコード**です。`Time`は枠の開始時刻から1秒刻みになります。

### 6.2 SAMPLING

先頭行はCSVヘッダで、次の行に単位が記録されます。

```csv
Date,Time,Data01,Data02,Data03,Data04,Data05,Data06,Data07,Data08
,,degC,V,Pa,degC,V,Pa,degC,V
```

以降は日時と8項目の数値が入ります。**最小20データ行**です。時刻は100ミリ秒刻み、数値は小数点以下3桁で生成されます。値はテスト用の計算値であり、実測値ではありません。

### 6.3 PROCESS

1ファイル全体が1つのJSONオブジェクトです。主な構造は以下のとおりです。

```text
ControlJobID
CarrierID
LotID
FlowRecipe
StartTime / EndTime
Wafers[]
  LocalID / WaferID / ProcessJobID
  TransferRoute[]
  StartTime / EndTime
  ChamberDatas[]
    Chamber / RecipeName
    StartTime / EndTime
    Steps[]
      StepNo / OriginalStepNo / RepeatStepCount
      StartTime / EndTime
      Datas[]
        Time / Name / Value / Unit
```

最初は1ウェハ（1ウェハあたり10測定データ）から構成し、`-ProcessSize`指定時はJSON全体のサイズが目標以上になるまでウェハを追加します。測定名は`Pressure`、単位は`Pa`、チャンバーは`A`です。日時にはローカルタイムゾーンのオフセットが付与されます。

## 7. ファイルサイズの仕様と検証

### 7.1 サイズは「下限」であり固定長ではない

- EVENT：最低2レコード。指定サイズに満たない場合、イベントレコードを追加。
- SAMPLING：最低20データ行。指定サイズに満たない場合、データ行を追加。
- PROCESS：最低1ウェハ。指定サイズに満たない場合、ウェハ情報を追加してJSONを作り直す。

各レコードやJSON構造を途中で切断しないため、生成ファイルは設定したサイズを超えることがあります。テキストは**UTF-8（BOMなし）**で書き込まれ、改行はCRLFです。

例：`28.1KB`の目標は `28.1 × 1024 = 28774.4`バイトで、整数のバイト数に丸めて扱われます。**29,573バイトのファイルなら、この目標を満たしています。**

### 7.2 件数・サイズを確認するPowerShell例

生成後に次のコマンドを実行します。

```powershell
$root = Join-Path (Get-Location) 'output'
$files = @(Get-ChildItem -LiteralPath $root -Recurse -File)
"Files: $($files.Count)"
$files | Group-Object Extension | Select-Object Name,Count
```

PROCESSファイルの最小サイズを検査する例（目標28.1KB、**バイト数で比較**）：

```powershell
$root = Join-Path (Get-Location) 'output'
$minimumBytes = [long](28.1 * 1KB)
$processFiles = @(Get-ChildItem -LiteralPath $root -Recurse -Filter '*.log' -File)
$short = @($processFiles | Where-Object { $_.Length -lt $minimumBytes })

"PROCESS files: $($processFiles.Count)"
"Target bytes : $minimumBytes"
"Below target : $($short.Count)"
$short | Select-Object FullName,Length
```

内容の形式を確認する例：

```powershell
# PROCESS: JSON構文確認
Get-Content -LiteralPath '.\output\n00-0\ProcessLog\20261031_000000.log' -Raw |
    ConvertFrom-Json | Out-Null

# SAMPLING: 先頭5行確認
Get-Content -LiteralPath '.\output\n00-0\SamplingLog\Chamber_24h\20261031_0000.csv' -TotalCount 5

# EVENT: 先頭1行のJSON構文確認
Get-Content -LiteralPath '.\output\n00-0\EventLog\PMC_00\20261031_00.evt' -TotalCount 1 |
    ConvertFrom-Json | Out-Null
```

※上記の具体的パスは`-Date 20261031`を指定して生成した例に対応します。

## 8. 実行結果とエラー

正常終了時は次の形式のメッセージを表示します。

```text
Done. Rebuilt: <出力先フルパス>
Date: 20261031  Count: 145  Kinds: EVENT, SAMPLING, PROCESS
```

主なエラー・確認事項：

| 状況 | 原因・対処 |
|---|---|
| `Invalid Date` | `yyyyMMdd`形式でも実在しない日付。例：`20260230`は不可 |
| `Invalid TargetSize` | サイズ表記が不正。例：`28.1KB`を使用 |
| `Unsafe OutputRoot` | ドライブのルート、またはスクリプト配置フォルダそのものを出力先に指定した |
| スクリプトの実行が禁止される | 実行ポリシー、ダウンロードファイルのブロック、社内セキュリティポリシーを確認 |
| アクセス拒否 | 出力先の権限、対象ファイルの使用状況を確認 |
| 取込処理で時刻エラー | `n24-0`でファイル名の時刻が`24:00`表現になる仕様を確認 |
| サイズ不足と検査される | 生成側と検査側で`KB`の換算（1024または1000）、小数の丸め、判定しきい値が一致しているか確認 |

## 9. 運用上の注意

1. **データ消失防止**：`OutputRoot`を指定する前に必ずパスを確認してください。スクリプトは出力先を再帰削除します。ドライブルートとスクリプト自身のフォルダを直接指定することは防止していますが、**それ以外の重要フォルダまで安全を保証するものではありません**。
2. **空き容量**：`Count`やサイズ指定を大きくすると、多数のファイルと大量のデータを生成します。試験開始時は少数枠で動作確認してください。
3. **日付と時刻**：`-Date`が指定されていても、IDの一部である`RunToken`は**実行時刻**から生成されます。再実行では同じパスのファイルが上書き生成され、内容のIDは変わる場合があります。
4. **カレンダー処理**：`Count=145`は翌日00:00枠を含みます。24時間の範囲内で00:00～23:50の144枠だけが必要なら`-Count 144`を指定します。
5. **データの用途**：値・IDはすべてテスト用に作られます。実機のログ仕様との適合性は試験対象システム側で別途確認してください。
6. **終了判定**：スクリプトは生成が完了するとメッセージを出力しますが、ファイルの完全性や業務的な整合性を網羅的にチェックする自動検証機能はありません。必要に応じて別途検証してください。

## 10. 推奨する最初の動作確認

次の順番を推奨します。

1. `-Date 20261031 -Count 3 -OutputRoot '.\output_trial'`で9ファイルを生成。
2. `output_trial`配下のフォルダ構造と3種類のログ内容を確認。
3. `-ProcessSize 28.1KB`を追加し、PROCESSのバイト数とJSON構文を確認。
4. 問題がなければ`-Count 145`で本番の試験データを生成。
5. 件数・サイズ・解析可否を検証してから対象システムに投入。

---

**対象実装との対応：** 本書は添付された`Make-CtcTestDataEx_24H.ps1`のパラメータ宣言、`New-EventContent`、`New-SamplingContent`、`New-ProcessContent`、出力先再作成処理およびメイン生成ループを確認して作成しています。

param(
    [Parameter(Mandatory = $true)]
    [string]$TestId,

    [ValidateRange(1, 3600)]
    [int]$SampleInterval = 1
)

$ErrorActionPreference = 'Stop'

if (-not $TestId -or $TestId.Trim().Length -eq 0) {
    throw 'TestId must not be empty.'
}
if ($TestId.IndexOfAny([System.IO.Path]::GetInvalidFileNameChars()) -ge 0) {
    throw "TestId contains characters that cannot be used in a file name: $TestId"
}

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$SetupScript = Join-Path $PSScriptRoot 'Setup-PerformanceCollection.ps1'
$WorkerScript = Join-Path $PSScriptRoot 'Invoke-PerformanceCollector.ps1'
$OutputDirectory = Join-Path $ProjectRoot 'output'
$LogDirectory = Join-Path $ProjectRoot 'logs'
$EffectiveCounterFile = Join-Path $ProjectRoot 'config\counters.effective.txt'
$StateFile = Join-Path $LogDirectory 'collection-state.json'

foreach ($RequiredScript in $SetupScript, $WorkerScript) {
    if (-not (Test-Path -LiteralPath $RequiredScript -PathType Leaf)) {
        throw "Required script not found: $RequiredScript"
    }
}

$SetupResult = & $SetupScript -SampleInterval $SampleInterval

if (Test-Path -LiteralPath $StateFile -PathType Leaf) {
    $PreviousState = Get-Content -LiteralPath $StateFile -Raw | ConvertFrom-Json
    if (Get-Process -Id $PreviousState.WorkerProcessId -ErrorAction SilentlyContinue) {
        throw "Performance collection is already running. ProcessId: $($PreviousState.WorkerProcessId)"
    }
    Remove-Item -LiteralPath $StateFile -Force
}

$Counters = @(Get-Content -LiteralPath $EffectiveCounterFile | Where-Object { $_.Trim() })
$StartTime = Get-Date
$Timestamp = $StartTime.ToString('yyyyMMdd_HHmmss')
$RunId = [Guid]::NewGuid().ToString('N')
$BlgPath = Join-Path $OutputDirectory "${TestId}_${Timestamp}.blg"
$LogPath = Join-Path $LogDirectory "${TestId}_${Timestamp}.log"
$StopRequestFile = Join-Path $LogDirectory "collector-$RunId.stop"
$ReadyFile = Join-Path $LogDirectory "collector-$RunId.ready"
$StandardOutputPath = Join-Path $LogDirectory "collector-$RunId.stdout.log"
$StandardErrorPath = Join-Path $LogDirectory "collector-$RunId.stderr.log"

$PowerShellPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
if (-not (Test-Path -LiteralPath $PowerShellPath -PathType Leaf)) {
    throw "Windows PowerShell is not available: $PowerShellPath"
}
$Arguments = @(
    '-NoLogo'
    '-NoProfile'
    '-NonInteractive'
    '-ExecutionPolicy', 'Bypass'
    '-File', ('"{0}"' -f $WorkerScript)
    '-CounterFile', ('"{0}"' -f $EffectiveCounterFile)
    '-BlgPath', ('"{0}"' -f $BlgPath)
    '-StopRequestFile', ('"{0}"' -f $StopRequestFile)
    '-ReadyFile', ('"{0}"' -f $ReadyFile)
    '-SampleInterval', $SampleInterval
) -join ' '

$WorkerProcess = Start-Process -FilePath $PowerShellPath -ArgumentList $Arguments -WindowStyle Hidden -PassThru `
    -RedirectStandardOutput $StandardOutputPath -RedirectStandardError $StandardErrorPath

$State = [PSCustomObject]@{
    TestId            = $TestId
    WorkerProcessId   = $WorkerProcess.Id
    StartTime         = $StartTime.ToString('yyyy-MM-dd HH:mm:ss')
    SampleInterval    = $SampleInterval
    CounterCount      = $Counters.Count
    BlgPath           = $BlgPath
    LogPath           = $LogPath
    StopRequestFile   = $StopRequestFile
    ReadyFile         = $ReadyFile
    StandardOutputPath = $StandardOutputPath
    StandardErrorPath = $StandardErrorPath
}
$State | ConvertTo-Json | Set-Content -LiteralPath $StateFile -Encoding UTF8

$Deadline = (Get-Date).AddSeconds(20)
while ((Get-Date) -lt $Deadline -and -not (Test-Path -LiteralPath $ReadyFile -PathType Leaf)) {
    if ($WorkerProcess.HasExited) {
        $ErrorText = if (Test-Path -LiteralPath $StandardErrorPath) { Get-Content -LiteralPath $StandardErrorPath -Raw } else { '' }
        foreach ($FailedFile in $StateFile, $StopRequestFile, $ReadyFile, $StandardOutputPath, $StandardErrorPath, $BlgPath) {
            Remove-Item -LiteralPath $FailedFile -Force -ErrorAction SilentlyContinue
        }
        throw "Collector process exited during startup. $ErrorText"
    }
    Start-Sleep -Milliseconds 250
    $WorkerProcess.Refresh()
}

if (-not (Test-Path -LiteralPath $ReadyFile -PathType Leaf)) {
    Set-Content -LiteralPath $StopRequestFile -Value 'Stop' -Encoding ASCII
    Remove-Item -LiteralPath $StateFile -Force -ErrorAction SilentlyContinue
    throw 'Timed out while starting performance counter collection.'
}

@(
    'Result=Started'
    "TestId=$TestId"
    "StartTime=$($State.StartTime)"
    "WorkerProcessId=$($WorkerProcess.Id)"
    "SampleInterval=$SampleInterval"
    "CounterCount=$($Counters.Count)"
    "BlgPath=$BlgPath"
) | Set-Content -LiteralPath $LogPath -Encoding UTF8

[PSCustomObject]@{
    Result         = 'Started'
    TestId         = $TestId
    ProcessId      = $WorkerProcess.Id
    CounterCount   = $Counters.Count
    SkippedCount   = $SetupResult.SkippedCount
    SampleInterval = $SampleInterval
    BlgPath        = $BlgPath
    StateFile      = $StateFile
    LogPath        = $LogPath
}

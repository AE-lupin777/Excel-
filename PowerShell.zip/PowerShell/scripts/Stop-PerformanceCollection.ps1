$ErrorActionPreference = 'Stop'

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$LogDirectory = Join-Path $ProjectRoot 'logs'
$StateFile = Join-Path $LogDirectory 'collection-state.json'
$ConvertScript = Join-Path $PSScriptRoot 'Convert-PerformanceLog.ps1'

if (-not (Test-Path -LiteralPath $StateFile -PathType Leaf)) {
    throw "Collection state file not found: $StateFile"
}
if (-not (Test-Path -LiteralPath $ConvertScript -PathType Leaf)) {
    throw "Conversion script not found: $ConvertScript"
}

$State = Get-Content -LiteralPath $StateFile -Raw | ConvertFrom-Json
$WorkerProcess = Get-Process -Id $State.WorkerProcessId -ErrorAction SilentlyContinue

if ($null -ne $WorkerProcess) {
    Set-Content -LiteralPath $State.StopRequestFile -Value 'Stop' -Encoding ASCII
    Wait-Process -Id $WorkerProcess.Id -Timeout 20 -ErrorAction SilentlyContinue
    if (Get-Process -Id $WorkerProcess.Id -ErrorAction SilentlyContinue) {
        throw "Collector process did not stop within 20 seconds. ProcessId: $($WorkerProcess.Id)"
    }
}

Start-Sleep -Milliseconds 500

if (Test-Path -LiteralPath $State.StandardErrorPath -PathType Leaf) {
    $ErrorText = Get-Content -LiteralPath $State.StandardErrorPath -Raw
    if ($null -eq $ErrorText) {
        $ErrorText = ''
    }
    else {
        $ErrorText = $ErrorText.Trim()
    }
    if ($ErrorText) {
        throw "Collector process reported an error: $ErrorText"
    }
}

if (-not (Test-Path -LiteralPath $State.BlgPath -PathType Leaf)) {
    throw "BLG file was not created: $($State.BlgPath)"
}

$Summary = Import-Counter -Path $State.BlgPath -Summary
$CounterCount = @((Import-Counter -Path $State.BlgPath -MaxSamples 1).CounterSamples).Count

if ($CounterCount -ne $State.CounterCount) {
    throw "Counter count mismatch. Expected: $($State.CounterCount), Actual: $CounterCount"
}

$WindowsPowerShell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
if (-not (Test-Path -LiteralPath $WindowsPowerShell -PathType Leaf)) {
    throw "Windows PowerShell is not available: $WindowsPowerShell"
}
$EscapedConvertScript = $ConvertScript.Replace("'", "''")
$EscapedBlgPath = ([string]$State.BlgPath).Replace("'", "''")
$ConversionCommand = "`$ProgressPreference = 'SilentlyContinue'; & '$EscapedConvertScript' -BlgPath '$EscapedBlgPath' | ConvertTo-Json -Compress"
$EncodedCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($ConversionCommand))
$ConversionJson = & $WindowsPowerShell -NoLogo -NoProfile -NonInteractive -OutputFormat Text -ExecutionPolicy Bypass -EncodedCommand $EncodedCommand
if ($LASTEXITCODE -ne 0) {
    throw "BLG to CSV conversion failed with exit code $LASTEXITCODE."
}
$ConversionResult = $ConversionJson | ConvertFrom-Json
$StopTime = Get-Date

@(
    "StopTime=$($StopTime.ToString('yyyy-MM-dd HH:mm:ss'))"
    'Result=Stopped'
    "SampleCount=$($Summary.SampleCount)"
    "CounterCount=$CounterCount"
    "CsvPath=$($ConversionResult.CsvPath)"
) | Add-Content -LiteralPath $State.LogPath -Encoding UTF8

foreach ($TemporaryFile in $State.StopRequestFile, $State.ReadyFile, $State.StandardOutputPath, $State.StandardErrorPath, $StateFile) {
    Remove-Item -LiteralPath $TemporaryFile -Force -ErrorAction SilentlyContinue
}

[PSCustomObject]@{
    Result       = 'Stopped'
    TestId       = $State.TestId
    StartTime    = $State.StartTime
    StopTime     = $StopTime.ToString('yyyy-MM-dd HH:mm:ss')
    SampleCount  = $Summary.SampleCount
    CounterCount = $CounterCount
    BlgPath      = $State.BlgPath
    CsvPath      = $ConversionResult.CsvPath
    DataRows     = $ConversionResult.DataRows
    ColumnCount  = $ConversionResult.ColumnCount
    LogPath      = $State.LogPath
}

param(
    [ValidateRange(3, 60)]
    [int]$DurationSeconds = 5,

    [switch]$KeepArtifacts
)

$ErrorActionPreference = 'Stop'

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$SetupScript = Join-Path $PSScriptRoot 'Setup-PerformanceCollection.ps1'
$StartScript = Join-Path $PSScriptRoot 'Start-PerformanceCollection.ps1'
$StopScript = Join-Path $PSScriptRoot 'Stop-PerformanceCollection.ps1'
$EffectiveCounterFile = Join-Path $ProjectRoot 'config\counters.effective.txt'
$StateFile = Join-Path $ProjectRoot 'logs\collection-state.json'

foreach ($RequiredScript in $SetupScript, $StartScript, $StopScript) {
    if (-not (Test-Path -LiteralPath $RequiredScript -PathType Leaf)) {
        throw "Required script not found: $RequiredScript"
    }
}

if (Get-Process -Name 'ULAgent.Sender' -ErrorAction SilentlyContinue) {
    throw 'A real or existing ULAgent.Sender process is already running. Self-test was cancelled.'
}

$CompilerCandidates = @(
    (Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'),
    (Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe')
)
$Compiler = $CompilerCandidates | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
if (-not $Compiler) {
    throw 'The standard Windows C# compiler was not found.'
}

$RunId = [Guid]::NewGuid().ToString('N')
$TempDirectory = Join-Path ([IO.Path]::GetTempPath()) "ULAgentPerformanceSelfTest-$RunId"
$MockSource = Join-Path $TempDirectory 'ULAgent.Sender.cs'
$MockExecutable = Join-Path $TempDirectory 'ULAgent.Sender.exe'
$MockWorkFile = Join-Path $TempDirectory 'mock-io.bin'
$TestId = "SELFTEST_$((Get-Date).ToString('yyyyMMdd_HHmmss'))"
$MockProcess = $null
$CollectionStarted = $false
$StopResult = $null

$SourceCode = @'
using System;
using System.Diagnostics;
using System.IO;
using System.Threading;

internal static class Program
{
    private static void Main(string[] args)
    {
        string workFile = args[0];
        byte[] memoryLoad = new byte[32 * 1024 * 1024];
        byte[] ioBuffer = new byte[256 * 1024];
        new Random(12345).NextBytes(ioBuffer);

        for (int i = 0; i < memoryLoad.Length; i += 4096)
        {
            memoryLoad[i] = (byte)(i % 251);
        }

        using (FileStream stream = new FileStream(workFile, FileMode.Create, FileAccess.ReadWrite, FileShare.Read))
        {
            while (true)
            {
                double value = 0;
                Stopwatch timer = Stopwatch.StartNew();
                while (timer.ElapsedMilliseconds < 80)
                {
                    for (int i = 1; i < 20000; i++)
                    {
                        value += Math.Sqrt(i);
                    }
                }

                stream.Position = 0;
                stream.Write(ioBuffer, 0, ioBuffer.Length);
                stream.Flush();
                stream.Position = 0;
                stream.Read(ioBuffer, 0, ioBuffer.Length);
                GC.KeepAlive(value);
                Thread.Sleep(120);
            }
        }
    }
}
'@

try {
    New-Item -ItemType Directory -Path $TempDirectory -Force | Out-Null
    Set-Content -LiteralPath $MockSource -Value $SourceCode -Encoding UTF8

    & $Compiler '/nologo' '/target:exe' '/optimize+' "/out:$MockExecutable" $MockSource
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $MockExecutable -PathType Leaf)) {
        throw "Failed to build the mock ULAgent.Sender process. Compiler exit code: $LASTEXITCODE"
    }

    $MockProcess = Start-Process -FilePath $MockExecutable -ArgumentList ('"{0}"' -f $MockWorkFile) -WindowStyle Hidden -PassThru

    $CounterDeadline = (Get-Date).AddSeconds(10)
    $MockCounterReady = $false
    while ((Get-Date) -lt $CounterDeadline) {
        try {
            $Sample = Get-Counter -Counter '\Process(ULAgent.Sender)\ID Process' -MaxSamples 1 -ErrorAction Stop
            if (@($Sample.CounterSamples).Count -gt 0) {
                $MockCounterReady = $true
                break
            }
        }
        catch {
            Start-Sleep -Milliseconds 250
        }
    }
    if (-not $MockCounterReady) {
        throw 'The mock ULAgent.Sender performance counter did not become available.'
    }

    $StartResult = & $StartScript -TestId $TestId
    $CollectionStarted = $true

    $EffectiveProcessCounters = @(
        Get-Content -LiteralPath $EffectiveCounterFile |
            Where-Object { $_ -match '^\\process\(ulagent\.sender' }
    )
    if ($EffectiveProcessCounters.Count -ne 6) {
        throw "Expected 6 ULAgent.Sender counters, but found $($EffectiveProcessCounters.Count)."
    }

    Start-Sleep -Seconds $DurationSeconds
    $StopResult = & $StopScript
    $CollectionStarted = $false

    if ($StopResult.SampleCount -lt 2) {
        throw "Too few samples were collected: $($StopResult.SampleCount)"
    }
    if ($StopResult.CounterCount -ne $StartResult.CounterCount) {
        throw "Counter count mismatch. Started: $($StartResult.CounterCount), Stopped: $($StopResult.CounterCount)"
    }
    if ($StopResult.DataRows -ne $StopResult.SampleCount) {
        throw "CSV row count mismatch. Samples: $($StopResult.SampleCount), Rows: $($StopResult.DataRows)"
    }
    foreach ($ResultFile in $StopResult.BlgPath, $StopResult.CsvPath, $StopResult.LogPath) {
        if (-not (Test-Path -LiteralPath $ResultFile -PathType Leaf)) {
            throw "Expected result file was not created: $ResultFile"
        }
    }

    [PSCustomObject]@{
        Result                  = 'Passed'
        TestId                  = $TestId
        MockProcess             = 'ULAgent.Sender'
        EffectiveCounterCount   = $StartResult.CounterCount
        ProcessCounterCount     = $EffectiveProcessCounters.Count
        SampleCount             = $StopResult.SampleCount
        CounterCount            = $StopResult.CounterCount
        DataRows                = $StopResult.DataRows
        ColumnCount             = $StopResult.ColumnCount
        ArtifactsKept           = [bool]$KeepArtifacts
        BlgPath                 = if ($KeepArtifacts) { $StopResult.BlgPath } else { $null }
        CsvPath                 = if ($KeepArtifacts) { $StopResult.CsvPath } else { $null }
        LogPath                 = if ($KeepArtifacts) { $StopResult.LogPath } else { $null }
    }
}
finally {
    if ($CollectionStarted -and (Test-Path -LiteralPath $StateFile -PathType Leaf)) {
        try { & $StopScript | Out-Null } catch { Write-Warning "Self-test collection cleanup failed: $($_.Exception.Message)" }
    }

    if ($null -ne $MockProcess -and -not $MockProcess.HasExited) {
        Stop-Process -Id $MockProcess.Id -Force -ErrorAction SilentlyContinue
        Wait-Process -Id $MockProcess.Id -Timeout 5 -ErrorAction SilentlyContinue
    }

    if ($null -ne $StopResult -and -not $KeepArtifacts) {
        foreach ($ResultFile in $StopResult.BlgPath, $StopResult.CsvPath, $StopResult.LogPath) {
            Remove-Item -LiteralPath $ResultFile -Force -ErrorAction SilentlyContinue
        }
    }

    foreach ($TempFile in $MockWorkFile, $MockExecutable, $MockSource) {
        Remove-Item -LiteralPath $TempFile -Force -ErrorAction SilentlyContinue
    }
    if (Test-Path -LiteralPath $TempDirectory -PathType Container) {
        Remove-Item -LiteralPath $TempDirectory -Force -ErrorAction SilentlyContinue
    }
}

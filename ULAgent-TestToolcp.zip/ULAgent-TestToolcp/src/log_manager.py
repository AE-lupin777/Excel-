from dataclasses import dataclass


@dataclass
class EventLog:

    source: str

    severity: str

    message: str


@dataclass
class SamplingLog:

    data01: float

    data02: float

    data03: float


@dataclass
class ProcessLog:

    lot_id: str

    recipe: str

    wafer_id: str
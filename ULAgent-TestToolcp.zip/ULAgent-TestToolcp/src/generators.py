import json
import csv

from datetime import datetime
from pathlib import Path


def get_output_dir():

    output_dir = (
        Path(__file__).parent.parent
        / "output"
    )

    output_dir.mkdir(
        exist_ok=True
    )

    return output_dir


def generate_event(
        source,
        severity,
        message):

    output_dir = get_output_dir()

    now = datetime.now()

    filename = (
        now.strftime("%Y%m%d_%H")
        + ".evt"
    )

    file_path = (
        output_dir
        / filename
    )

    event_data = {

        "Time":
            now.strftime(
                "%Y/%m/%d %H:%M:%S.000+09:00"
            ),

        "Source":
            source,

        "LogType":
            "Log",

        "Severity":
            severity,

        "Message":
            message,

        "MetaData":
            ""
    }

    with open(
            file_path,
            "w",
            encoding="utf-8") as f:

        f.write(
            json.dumps(
                event_data,
                ensure_ascii=False
            )
        )

    return file_path


def generate_sampling(data):

    output_dir = get_output_dir()

    now = datetime.now()

    filename = (
        now.strftime("%Y%m%d_%H%M")
        + ".csv"
    )

    file_path = (
        output_dir
        / filename
    )

    with open(
            file_path,
            "w",
            newline="",
            encoding="utf-8") as f:

        writer = csv.writer(f)

        writer.writerow(
            [
                "Date",
                "Time",
                "Data01",
                "Data02",
                "Data03"
            ]
        )

        writer.writerow(
            [
                "",
                "",
                "degC",
                "Pa",
                "V"
            ]
        )

        writer.writerow(
            [
                now.strftime("%Y/%m/%d"),
                now.strftime("%H:%M:%S.000+09:00"),
                data["data01"],
                data["data02"],
                data["data03"]
            ]
        )

    return file_path

def generate_process(data):

    output_dir = get_output_dir()

    now = datetime.now()

    filename = (
        now.strftime("%Y%m%d_%H%M%S")
        + ".log"
    )

    file_path = (
        output_dir
        / filename
    )

    process_data = {

        "ControlJobID":
            "CJ-001",

        "CarrierID":
            "CARRIER-001",

        "LotID":
            data["lot_id"],

        "FlowRecipe":
            data["recipe"],

        "StartTime":
            now.strftime(
                "%Y/%m/%d %H:%M:%S.000+09:00"
            ),

        "EndTime":
            now.strftime(
                "%Y/%m/%d %H:%M:%S.000+09:00"
            ),

        "Wafers": [

            {

                "LocalID":
                    "0001",

                "WaferID":
                    data["wafer_id"],

                "ProcessJobID":
                    "PJ-001",

                "TransferRoute":
                    ["A"],

                "StartTime":
                    now.strftime(
                        "%Y/%m/%d %H:%M:%S.000+09:00"
                    ),

                "EndTime":
                    now.strftime(
                        "%Y/%m/%d %H:%M:%S.000+09:00"
                    ),

                "ChamberDatas": []

            }
        ]
    }

    with open(
            file_path,
            "w",
            encoding="utf-8") as f:

        json.dump(
            process_data,
            f,
            indent=4,
            ensure_ascii=False
        )

    return file_path
import sys

from pathlib import Path
import json

from generators import (
    generate_event,
    generate_sampling,
    generate_process
)

from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QLabel,
    QPushButton,
    QComboBox,
    QLineEdit,
    QGroupBox,
    QFormLayout,
    QMessageBox
)

class MainWindow(QMainWindow):

    def __init__(self):

        super().__init__()

        self.setWindowTitle(
            "ULAgent Test Data Designer"
        )

        self.resize(800, 600)

        widget = QWidget()

        self.setCentralWidget(widget)

        layout = QVBoxLayout(widget)

        #
        # シナリオ選択
        #
        layout.addWidget(
            QLabel("テストシナリオ")
        )

        self.scenario_combo = QComboBox()

        layout.addWidget(
            self.scenario_combo
        )

        self.load_scenarios()

        #
        # 接続先
        #
        connection_group = QGroupBox(
            "接続先"
        )

        connection_layout = QFormLayout()

        self.connection_combo = QComboBox()

        self.connection_combo.addItems(
            [
                "PMC",
                "TMC",
                "CTC"
            ]
        )

        connection_layout.addRow(
            "Connection",
            self.connection_combo
        )

        connection_group.setLayout(
            connection_layout
        )

        layout.addWidget(
            connection_group
        )

        #
        # Chamber
        #
        chamber_group = QGroupBox(
            "Chamber"
        )

        chamber_layout = QFormLayout()

        self.chamber_combo = QComboBox()

        self.chamber_combo.addItems(
            [
                "Chamber-A",
                "Chamber-B",
                "Chamber-C"
            ]
        )

        chamber_layout.addRow(
            "Chamber",
            self.chamber_combo
        )

        chamber_group.setLayout(
            chamber_layout
        )

        layout.addWidget(
            chamber_group
        )

        #
        # EVENT
        #
        event_group = QGroupBox(
            "EVENT"
        )

        event_layout = QFormLayout()

        self.severity_combo = QComboBox()

        self.severity_combo.addItems(
            [
                "Info",
                "Warn",
                "Error"
            ]
        )

        self.message_edit = QLineEdit()

        self.message_edit.setText(
            "Test Start"
        )

        event_layout.addRow(
            "Severity",
            self.severity_combo
        )

        event_layout.addRow(
            "Message",
            self.message_edit
        )

        event_group.setLayout(
            event_layout
        )

        layout.addWidget(
            event_group
        )

        #
        # PROCESS
        #
        process_group = QGroupBox(
            "PROCESS"
        )

        process_layout = QFormLayout()

        self.lot_id_edit = QLineEdit()

        self.lot_id_edit.setText(
            "LOT-001"
        )

        self.recipe_edit = QLineEdit()

        self.recipe_edit.setText(
            "TEST_RECIPE_01"
        )

        self.wafer_id_edit = QLineEdit()

        self.wafer_id_edit.setText(
            "WF-001"
        )

        process_layout.addRow(
            "LotID",
            self.lot_id_edit
        )

        process_layout.addRow(
            "Recipe",
            self.recipe_edit
        )

        process_layout.addRow(
            "WaferID",
            self.wafer_id_edit
        )

        process_group.setLayout(
            process_layout
        )

        layout.addWidget(
            process_group
        )

        #
        # Save Scenarioボタン
        #
        self.save_button = QPushButton(
            "Save Scenario"
        )

        self.save_button.clicked.connect(
            self.save_scenario
        )

        layout.addWidget(
            self.save_button
        )

        #
        # Generateボタン
        #
        self.generate_button = QPushButton(
            "Generate"
        )

        self.generate_button.clicked.connect(
            self.generate
        )

        layout.addWidget(
            self.generate_button
        )

        #
        # シナリオロード設定
        #
        self.scenario_combo.currentTextChanged.connect(
            self.load_scenario
        )

        if self.scenario_combo.count() > 0:
            self.load_scenario()

    def load_scenarios(self):

        scenario_dir = (
            Path(__file__).parent.parent
            / "scenarios"
        )

        if not scenario_dir.exists():
            return

        for file in scenario_dir.glob(
            "*.json"
        ):
            self.scenario_combo.addItem(
                file.stem
            )

    def generate(self):

        root_dir = (
            Path(__file__).parent.parent
        )

        scenario_file = (
            root_dir
            / "scenarios"
            / f"{self.scenario_combo.currentText()}.json"
        )

        with open(
                scenario_file,
                "r",
                encoding="utf-8") as f:

            scenario = json.load(f)

        event_data = {

            "source":
                self.connection_combo.currentText(),

            "severity":
                self.severity_combo.currentText(),

            "message":
                self.message_edit.text()
        }

        event_file = generate_event(
            **event_data
        )

        sampling_file = generate_sampling(
            scenario["sampling"]
        )

        process_data = {

            "lot_id":
                self.lot_id_edit.text(),

            "recipe":
                self.recipe_edit.text(),

            "wafer_id":
                self.wafer_id_edit.text()
        }

        process_file = generate_process(
            process_data
        )

        QMessageBox.information(

            self,

            "完了",

            f"""EVENT生成完了

            {event_file}

            SAMPLING生成完了

            {sampling_file}

            PROCESS生成完了

            {process_file}
            """
        )

    def save_scenario(self):

        scenario_name = (
            self.scenario_combo.currentText()
        )

        if not scenario_name:

            QMessageBox.warning(
                self,
                "エラー",
                "シナリオ名がありません"
            )

            return

        scenario = {

            "event": {

                "source":
                    self.connection_combo.currentText(),

                "severity":
                    self.severity_combo.currentText(),

                "message":
                    self.message_edit.text()
            },

            "sampling": {

                "data01": 100.25,
                "data02": 100.50,
                "data03": 100.75
            },

            "process": {

                "lot_id":
                    self.lot_id_edit.text(),

                "recipe":
                    self.recipe_edit.text(),

                "wafer_id":
                    self.wafer_id_edit.text()
            }
        }

        scenario_file = (
            Path(__file__).parent.parent
            / "scenarios"
            / f"{scenario_name}.json"
        )

        with open(
                scenario_file,
                "w",
                encoding="utf-8") as f:

            json.dump(
                scenario,
                f,
                indent=4,
                ensure_ascii=False
            )

        QMessageBox.information(

            self,

            "保存完了",

            f"{scenario_name}.json を保存しました"
        )

    def load_scenario(self):

        scenario_name = (
            self.scenario_combo.currentText()
        )

        if not scenario_name:
            return

        scenario_file = (
            Path(__file__).parent.parent
            / "scenarios"
            / f"{scenario_name}.json"
        )

        if not scenario_file.exists():
            return

        with open(
                scenario_file,
                "r",
                encoding="utf-8") as f:

            scenario = json.load(f)

        #
        # EVENT
        #
        severity = scenario["event"]["severity"]

        index = self.severity_combo.findText(
            severity
        )

        if index >= 0:
            self.severity_combo.setCurrentIndex(
                index
            )

        self.message_edit.setText(
            scenario["event"]["message"]
        )

        #
        # PROCESS
        #
        self.lot_id_edit.setText(
            scenario["process"]["lot_id"]
        )

        self.recipe_edit.setText(
            scenario["process"]["recipe"]
        )

        self.wafer_id_edit.setText(
            scenario["process"]["wafer_id"]
        )

app = QApplication(sys.argv)

window = MainWindow()

window.show()

sys.exit(app.exec())
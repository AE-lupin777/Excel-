## Performance Counter収集・分析手順書 Ver.0.5

### 1. 目的

ULAgent総合試験に向けて、Windows上のシステム全体およびULAgentプロセスのリソース使用状況を収集・分析する。

本手順書ではSender PC / Receiver PCの双方を、同一の収集ツール一式で扱う。

本手順書では以下を実施する。
- 実行Role（sender / receiver）の設定
- 実行環境と利用可能カウンターの自動確認
- Performance Counter収集
- BLG原本保存
- CSV変換
- Power Query分析
- 試験記録作成

> 本ツールはWindows用である。Linux環境は本手順書の対象外とし、別途確認する。

### 2. 前提条件

- Windows環境
- Windows PowerShell 5.1が利用可能
- 測定対象に応じ、次のサービスが起動している
  - Sender PC: `ULAgent.Sender`
  - Receiver PC: `ULAgent.Receiver`
- ExcelおよびPower Queryが利用可能（分析時のみ）

管理者権限はPerformance Counter収集には原則不要。ULAgentサービスの登録・起動操作には管理者権限が必要。

#### フォルダ構成

```text
PowerShell
├─ Initialize-PerformanceCollection.cmd  … 初期化入口。sender / receiverを指定
├─ config
│  ├─ counters.txt                       … 共通カウンターテンプレート
│  ├─ role.conf                          … Initialize実行時に自動生成
│  └─ counters.effective.txt             … Setup実行時に自動生成
├─ logs
├─ output
├─ scripts
│  ├─ PerformanceCollection.cmd
│  ├─ Setup-PerformanceCollection.ps1
│  ├─ Start-PerformanceCollection.ps1
│  ├─ Invoke-PerformanceCollector.ps1
│  ├─ Stop-PerformanceCollection.ps1
│  ├─ Test-PerformanceCollection.ps1
│  └─ Convert-PerformanceLog.ps1
├─ CounterList_Ver0.1.md
├─ TestExecutionRecord_Ver0.1.md
└─ Day3_FileCopyAnalysis.xlsx
```

### 3. Roleと対象プロセス

初期化時の引数により、測定対象プロセスを自動的に切り替える。

- `sender` → `ULAgent.Sender`
- `receiver` → `ULAgent.Receiver`

`config\counters.txt`のProcessカウンターは次の共通テンプレートで定義する。

```text
\Process({PROCESS_NAME})\% Processor Time
\Process({PROCESS_NAME})\Working Set - Private
\Process({PROCESS_NAME})\Private Bytes
\Process({PROCESS_NAME})\IO Read Bytes/sec
\Process({PROCESS_NAME})\IO Write Bytes/sec
\Process({PROCESS_NAME})\ID Process
```

`Setup-PerformanceCollection.ps1`が`config\role.conf`を読み、`{PROCESS_NAME}`を対象プロセス名へ展開する。

Receiverで`counters.txt`を手作業で書き換える必要はない。

### 4. 収集対象

#### システム全体

```text
\Processor(_Total)\% Processor Time
\Memory\Available Bytes
```

#### Disk

```text
\PhysicalDisk(_Total)\Disk Read Bytes/sec
\PhysicalDisk(_Total)\Disk Write Bytes/sec
\PhysicalDisk(_Total)\Disk Transfers/sec
\PhysicalDisk(_Total)\Avg. Disk Queue Length
```

#### Network

```text
\Network Interface(<対象NIC>)\Bytes Received/sec
\Network Interface(<対象NIC>)\Bytes Sent/sec
```

`Setup-PerformanceCollection.ps1`が実行PCで利用可能なNICを検出する。複数NICが存在するPCでは複数のNetwork Interfaceカウンターが`counters.effective.txt`へ展開される場合がある。

実際のULAgent通信に使用されるNICの特定は、必要に応じて試験時に別途行う。収集時点では複数NICの値を保持する。

#### ULAgentプロセス

Roleに対応するULAgentプロセスについて、以下を収集する。

```text
% Processor Time
Working Set - Private
Private Bytes
IO Read Bytes/sec
IO Write Bytes/sec
ID Process
```

このため、PC全体のリソース使用状況とULAgentプロセス単体の使用状況を区別して確認できる。

### 5. 環境準備

PowerShellフォルダ直下で、対象PCに応じて初期化ランチャーを実行する。

#### Sender PC

PowerShellから実行する場合:

```powershell
.\Initialize-PerformanceCollection.cmd sender
```

#### Receiver PC

```powershell
.\Initialize-PerformanceCollection.cmd receiver
```

コマンドプロンプトから実行する場合は、先頭の`.\`は省略可能。

初期化ランチャーは次を実施する。

1. Roleを決定する。
2. `config\role.conf`へRoleを保存する。
3. 各PS1のインターネット由来ブロックを解除する。
4. `Setup-PerformanceCollection.ps1`を実行する。
5. Roleに対応する実ULAgentプロセスの稼働有無を確認する。
6. 実プロセスが稼働中なら自己診断を正常スキップする。
7. 実プロセスが存在しない場合は、Roleに対応した自己診断を実行する。

実サービスを検出して`Self-test: Skipped (real ULAgent.Sender is running)`または`Self-test: Skipped (real ULAgent.Receiver is running)`と表示されるのは正常結果である。

ランチャーはPowerShell 7が利用可能ならPowerShell 7を使用し、存在しないPCではWindows標準のWindows PowerShell 5.1へ切り替える。Performance Counterの収集ワーカーは互換性確保のためWindows PowerShell 5.1を使用する。

ランチャーが使用するPowerShellプロセスではExecutionPolicyを一時的に`Bypass`とし、PC全体やユーザーの実行ポリシーは変更しない。

#### Setupで実施する内容

- `output`、`logs`、`config`フォルダの作成
- `config\role.conf`の確認
- Roleに応じた対象プロセス名の決定
- `counters.txt`内の`{PROCESS_NAME}`展開
- 必要なPowerShellコマンドと実行条件の確認
- PC固有のNIC名の解決
- 利用できないカウンターの除外
- `config\counters.effective.txt`の生成

正常時は`Result : Ready`が表示される。

確認ポイント:

```text
Role        : sender または receiver
ProcessName : ULAgent.Sender または ULAgent.Receiver
SkippedCount: 0（実機の構成により利用不可カウンターがある場合を除く）
```

Setupだけを再実行する場合:

```powershell
.\scripts\PerformanceCollection.cmd setup
```

または:

```powershell
& '.\scripts\Setup-PerformanceCollection.ps1'
```

Setupは`role.conf`を使用するため、初回は必ずInitializeを実行する。

### 6. 収集開始

#### 実行前確認

- Initializeが正常終了している
- Roleが対象PCと一致している
- Roleに対応するULAgentサービスが起動している
- `Setup-PerformanceCollection.ps1`が正常終了する
- `output`および`logs`へ書き込める
- 同じTestIDの既存出力と重複しない

#### 推奨実行方法

PowerShellフォルダ直下から:

```powershell
.\scripts\PerformanceCollection.cmd start <TestID>
```

scriptsフォルダに移動している場合:

```powershell
.\PerformanceCollection.cmd start <TestID>
```

例:

```powershell
.\scripts\PerformanceCollection.cmd start DAY3-FILECOPY-001
```

PowerShellスクリプトを直接実行する場合:

```powershell
& '.\scripts\Start-PerformanceCollection.ps1' -TestId '<TestID>'
```

StartスクリプトはSetupも自動実行する。Initialize時に保存されたRoleがStart時にも使用され、`counters.effective.txt`が再生成される。

既定の収集周期は1秒。

正常時は次の項目が表示される。

```text
Result         : Started
TestId         : <TestID>
ProcessId      : <収集プロセスID>
CounterCount   : <このPCで有効なカウンター数>
SkippedCount   : <除外されたカウンター数>
SampleInterval : 1
BlgPath        : <出力先>
```

収集はStop要求を受けるまで継続する。

### 7. 試験実施

基本的な流れ:

```text
収集開始
  ↓
事前待機
  ↓
試験操作
  ↓
処理完了を確認
  ↓
事後待機
  ↓
収集停止
```

Resource Timeline用途では、処理イベント発生時だけ収集するのではなく、試験開始前から試験終了後まで継続して取得する。

### 8. 収集停止

PowerShellフォルダ直下から:

```powershell
.\scripts\PerformanceCollection.cmd stop
```

scriptsフォルダ内から:

```powershell
.\PerformanceCollection.cmd stop
```

PowerShellスクリプトを直接実行する場合:

```powershell
& '.\scripts\Stop-PerformanceCollection.ps1'
```

開始時と同じPowerShell画面でなくても停止できる。

Stop処理ではCollectorを停止し、BLGを確認した後、CSV変換を自動実施する。

正常時は次の項目が表示される。

```text
Result
TestId
StartTime
StopTime
SampleCount
CounterCount
BlgPath
CsvPath
DataRows
ColumnCount
LogPath
```

### 9. 結果確認

確認項目:

- `SampleCount > 0`
- `CounterCount`が開始時の表示値と一致する
- BLGファイルが存在する
- CSVファイルが存在する
- `DataRows = SampleCount`
- `ColumnCount = CounterCount + 1`

CSVの追加1列はTimestamp列である。

NICが複数あるPCではNetwork Interfaceが複数展開されるため、`CounterCount`は`counters.txt`の定義数と一致しない場合がある。

必要時の手動変換:

```powershell
& '.\scripts\Convert-PerformanceLog.ps1' -BlgPath '<BLGファイル>'
```

### 10. Timestamp・時刻に関する注意事項

CSVの実出力では、各サンプルのTimestampがミリ秒3桁を含む形式で記録されることを確認している。

収集周期が1秒でも、各Timestampを1秒単位に丸めない。実際にCSVへ記録されたTimestampを原値として保持する。

Sender / Receiverのような複数PCのデータを共通時間軸へ統合するときは、PC間の時計差が存在する可能性を考慮する。

- raw Timestampは書き換えない
- Viewer側で理由なく時刻補正しない
- timezone、時計同期状態、PC間offset等は必要に応じて別情報として管理する
- 時刻補正が必要になった場合でも、raw Timestampを保持したまま解析用時刻を別途持つ

### 11. 欠損値に関する注意事項

Performance Counterの初回サンプルなどで、一部カウンターが空欄になる場合がある。

欠損値は0へ置換しない。

```text
空欄 = Missing / null
0    = 実測値0
```

として区別する。

### 12. Power Query更新

分析ブック:

```text
Day3_FileCopyAnalysis.xlsx
```

更新手順:

```text
Excel起動
 ↓
データ
 ↓
クエリと接続
 ↓
接続先CSV変更
 ↓
すべて更新
```

CSV列数はPC上で有効になったカウンター数により変わる可能性がある。列名とデータ行数を確認する。

### 13. 試験記録

記録先:

```text
TestExecutionRecord_Ver0.1.md
```

記録項目:

- TestID
- 収集開始日時
- 収集終了日時
- Role（sender / receiver）
- 対象PC
- 対象プロセス（ULAgent.Sender / ULAgent.Receiver）
- 対象NIC
- BLG、CSV、ログのパス
- SampleInterval
- SampleCount
- CounterCount
- SkippedCount
- DataRows
- ColumnCount
- 結果
- 備考

### 14. 異常時確認

#### Role未設定・不正

`role.conf`が存在しない、またはRoleが不正な場合はInitializeを実行する。

Sender:

```powershell
.\Initialize-PerformanceCollection.cmd sender
```

Receiver:

```powershell
.\Initialize-PerformanceCollection.cmd receiver
```

#### カウンター取得失敗・SkippedCount発生

- Roleに対応するULAgentサービスが起動しているか
- `role.conf`の内容が対象PCと一致しているか
- 警告に表示されたカウンターが対象PCに存在するか
- 対象NICが有効か

`counters.txt`の`{PROCESS_NAME}`をSender/Receiverごとに手編集しない。

#### 収集開始済みエラー

`logs\collection-state.json`が存在し、記録された収集プロセスが稼働している場合は、先にStopスクリプトを実行する。

#### BLG未作成

確認項目:

- `output`フォルダへの書込み権限
- `logs\collector-*.stderr.log`
- Windows PowerShell 5.1の存在

#### CSV変換失敗

BLGファイルの存在とCollector停止状態を確認する。

#### 欠損値

初回サンプル、欠損カウンター、発生時刻を確認する。欠損値は0へ置換しない。

### 15. 自己診断

実機の対象ULAgentサービスが存在しないPCでは、Roleに応じた模擬プロセスを作成し、Performance Counter収集からCSV変換までを自己診断する。

InitializeはRoleに対応する実サービスがすでに動作している場合、Self-testを正常スキップする。

自己診断を直接実行する場合はRole指定が必要となる。

Sender例:

```powershell
& '.\scripts\Test-PerformanceCollection.ps1' -Role sender
```

Receiver例:

```powershell
& '.\scripts\Test-PerformanceCollection.ps1' -Role receiver
```

確認用成果物を残す場合:

```powershell
& '.\scripts\Test-PerformanceCollection.ps1' -Role sender -KeepArtifacts
```

または:

```powershell
& '.\scripts\Test-PerformanceCollection.ps1' -Role receiver -KeepArtifacts
```

> 実サービス稼働中に自己診断を強制実行しない。実サービスを検出した場合は自己診断を中止する。

### 16. 成果物

#### 設定

```text
config\counters.txt
config\role.conf
config\counters.effective.txt
```

`role.conf`と`counters.effective.txt`は実行環境から生成されるファイルである。

#### 実行ファイル

```text
Initialize-PerformanceCollection.cmd
scripts\PerformanceCollection.cmd
scripts\Setup-PerformanceCollection.ps1
scripts\Start-PerformanceCollection.ps1
scripts\Invoke-PerformanceCollector.ps1
scripts\Stop-PerformanceCollection.ps1
scripts\Test-PerformanceCollection.ps1
scripts\Convert-PerformanceLog.ps1
```

#### 収集結果

```text
output\*.blg
output\*.csv
logs\*.log
```

#### 関連資料

```text
Day3_FileCopyAnalysis.xlsx
CounterList_Ver0.1.md
TestExecutionRecord_Ver0.1.md
```

### 17. Sender / Receiver実機確認結果

Role共通化後のツールについて、Sender PC / Receiver PCの双方で以下の一連の処理が正常に完了することを確認済み。

```text
Initialize
  ↓
Setup
  ↓
Start
  ↓
Performance Counter継続収集
  ↓
BLG保存
  ↓
Stop
  ↓
CSV変換
```

#### Sender確認結果

- Role: `sender`
- ProcessName: `ULAgent.Sender`
- SkippedCount: `0`
- CounterCount: `16`
- SampleInterval: `1`
- SampleCount: `76`
- DataRows: `76`
- ColumnCount: `17`

#### Receiver確認結果

- Role: `receiver`
- ProcessName: `ULAgent.Receiver`
- SkippedCount: `0`
- CounterCount: `24`
- SampleInterval: `1`
- SampleCount: `93`
- DataRows: `93`
- ColumnCount: `25`

CounterCountの差は実行PCで展開された利用可能カウンター数の違いによる。

### 18. Linux環境について

本ツールはWindows Performance CounterおよびWindows PowerShellを使用するWindows用Resource Collectorである。

Linux環境で同一ツールを使用する前提にはしない。Linux側のOSリソース収集方式は別途確認・設計する。

### 19. デジタル署名エラー

次の趣旨のエラーが表示された場合は、PS1を直接実行せずランチャー経由の実行を優先する。

```text
デジタル署名されていません。
現在のシステムでこのスクリプトを実行することはできません。
```

ランチャーはPS1に付いたインターネット由来のブロックを解除し、そのPowerShellプロセスだけExecutionPolicy Bypassで実行する。PC全体やユーザーの実行ポリシーは変更しない。

ランチャーでも同じ署名エラーになる場合は、会社・組織のグループポリシーで署名済みスクリプトが必須になっている可能性がある。その場合は設定を回避せず、管理者へコード署名または実行許可を依頼する。

### 20. 運用上の注意

- `counters.txt`はSender/Receiver共通テンプレートとして管理し、Roleごとに手編集しない。
- `role.conf`はInitializeから生成する。
- `counters.effective.txt`はSetupから自動生成するため直接編集しない。
- BLGを収集原本として保持する。
- CSVは分析・Timeline統合用データとして扱う。
- 複数NICの値は失わず保持し、必要なNICの特定は解析時または実試験時に行う。
- raw Timestampと欠損値を加工して証跡を失わない。
- Linux側Resource CollectorはWindows版と分離して扱う。

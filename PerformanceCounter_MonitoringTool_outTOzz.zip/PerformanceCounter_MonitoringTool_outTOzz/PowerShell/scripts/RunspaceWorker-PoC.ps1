param(
    [Parameter(Mandatory = $true)]
    [string]$CounterFile,

    [Parameter(Mandatory = $true)]
    [string]$ReadyFile
)

$ErrorActionPreference = 'Stop'

$Counters = @(
    Get-Content -LiteralPath $CounterFile |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ }
)

$sw = [System.Diagnostics.Stopwatch]::StartNew()

$ps = [PowerShell]::Create()

[void]$ps.AddScript(@'
param(
    [string[]]$JobCounters,
    [string]$ReadyPath
)

$ReadySent = $false

Get-Counter `
    -Counter $JobCounters `
    -SampleInterval 1 `
    -Continuous |
    ForEach-Object {

        if (-not $ReadySent) {

            Set-Content `
                -LiteralPath $ReadyPath `
                -Value "READY" `
                -Encoding ASCII

            $ReadySent = $true
        }

        $_

        break
    }
'@)

[void]$ps.AddArgument([string[]]$Counters)
[void]$ps.AddArgument($ReadyFile)

$r = $ps.BeginInvoke()

while (-not (Test-Path $ReadyFile)) {
    Start-Sleep -Milliseconds 10
}

$sw.Elapsed.TotalSeconds

$ps.Stop()
$ps.Dispose()
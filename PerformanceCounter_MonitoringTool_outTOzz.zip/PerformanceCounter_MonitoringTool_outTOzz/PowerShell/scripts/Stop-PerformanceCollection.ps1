$ErrorActionPreference = 'Stop'

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$LogDirectory = Join-Path $ProjectRoot 'logs'
$StateFile = Join-Path $LogDirectory 'collection-state.json'
$ConvertScript = Join-Path $PSScriptRoot 'Convert-PerformanceLog.ps1'


# ------------------------------------------------------------
# ログへ安全に追記する
# ------------------------------------------------------------
function Add-LogLines {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string[]]$Lines
    )

    $MaxRetry = 5
    $RetryIntervalMilliseconds = 200

    for ($Attempt = 1; $Attempt -le $MaxRetry; $Attempt++) {
        $Stream = $null
        $Writer = $null

        try {
            $Stream = New-Object System.IO.FileStream(
                $Path,
                [System.IO.FileMode]::Append,
                [System.IO.FileAccess]::Write,
                [System.IO.FileShare]::ReadWrite
            )

            # BOMなしUTF-8
            $Encoding = New-Object System.Text.UTF8Encoding($false)

            $Writer = New-Object System.IO.StreamWriter(
                $Stream,
                $Encoding
            )

            foreach ($Line in $Lines) {
                $Writer.WriteLine($Line)
            }

            $Writer.Flush()
            return
        }
        catch {
            if ($Attempt -ge $MaxRetry) {
                throw "Failed to append collection log after $MaxRetry attempts. Path: $Path`r`n$($_.Exception.Message)"
            }

            Start-Sleep -Milliseconds $RetryIntervalMilliseconds
        }
        finally {
            if ($null -ne $Writer) {
                $Writer.Dispose()
            }
            elseif ($null -ne $Stream) {
                $Stream.Dispose()
            }
        }
    }
}


# ------------------------------------------------------------
# 必要ファイル確認
# ------------------------------------------------------------
if (-not (Test-Path -LiteralPath $StateFile -PathType Leaf)) {
    throw "Collection state file not found: $StateFile"
}

if (-not (Test-Path -LiteralPath $ConvertScript -PathType Leaf)) {
    throw "Conversion script not found: $ConvertScript"
}


# ------------------------------------------------------------
# 収集状態取得
# ------------------------------------------------------------
$State = Get-Content -LiteralPath $StateFile -Raw | ConvertFrom-Json


# ------------------------------------------------------------
# Collector停止要求
# ------------------------------------------------------------
$WorkerProcess = Get-Process `
    -Id $State.WorkerProcessId `
    -ErrorAction SilentlyContinue

if ($null -ne $WorkerProcess) {
    Set-Content `
        -LiteralPath $State.StopRequestFile `
        -Value 'Stop' `
        -Encoding ASCII

    Wait-Process `
        -Id $WorkerProcess.Id `
        -Timeout 20 `
        -ErrorAction SilentlyContinue

    if (Get-Process -Id $WorkerProcess.Id -ErrorAction SilentlyContinue) {
        throw "Collector process did not stop within 20 seconds. ProcessId: $($WorkerProcess.Id)"
    }
}


# Collector終了直後のファイル開放待ち
Start-Sleep -Milliseconds 500


# ------------------------------------------------------------
# Collectorエラー確認
# ------------------------------------------------------------
if (Test-Path -LiteralPath $State.StandardErrorPath -PathType Leaf) {
    $ErrorText = Get-Content `
        -LiteralPath $State.StandardErrorPath `
        -Raw

    if ($null -eq $ErrorText) {
        $ErrorText = ''
    }
    else {
        $ErrorText = $ErrorText.Trim()
    }

    if ($ErrorText) {
        throw "Collector process reported an error: $ErrorText"
    }
}


# ------------------------------------------------------------
# BLG確認
# ------------------------------------------------------------
if (-not (Test-Path -LiteralPath $State.BlgPath -PathType Leaf)) {
    throw "BLG file was not created: $($State.BlgPath)"
}


$Summary = Import-Counter `
    -Path $State.BlgPath `
    -Summary


$CounterCount = @(
    (
        Import-Counter `
            -Path $State.BlgPath            -MaxSamples 1
    ).CounterSamples
).Count


if ($CounterCount -ne $State.CounterCount) {
    throw "Counter count mismatch. Expected: $($State.CounterCount), Actual: $CounterCount"
}


# ------------------------------------------------------------
# Windows PowerShell確認
# ------------------------------------------------------------
$WindowsPowerShell = Join-Path `
    $env:SystemRoot `
    'System32\WindowsPowerShell\v1.0\powershell.exe'


if (-not (Test-Path -LiteralPath $WindowsPowerShell -PathType Leaf)) {
    throw "Windows PowerShell is not available: $WindowsPowerShell"
}


# ------------------------------------------------------------
# BLG -> CSV変換
# ------------------------------------------------------------
$EscapedConvertScript = $ConvertScript.Replace("'", "''")
$EscapedBlgPath = ([string]$State.BlgPath).Replace("'", "''")


$ConversionCommand = "`$ProgressPreference = 'SilentlyContinue'; & '$EscapedConvertScript' -BlgPath '$EscapedBlgPath' | ConvertTo-Json -Compress"


$EncodedCommand = [Convert]::ToBase64String(
    [Text.Encoding]::Unicode.GetBytes($ConversionCommand)
)


$ConversionJson = & $WindowsPowerShell `
    -NoLogo `
    -NoProfile `
    -NonInteractive `
    -OutputFormat Text `
    -ExecutionPolicy Bypass `
    -EncodedCommand $EncodedCommand


if ($LASTEXITCODE -ne 0) {
    throw "BLG to CSV conversion failed with exit code $LASTEXITCODE."
}


$ConversionResult = $ConversionJson | ConvertFrom-Json


# ------------------------------------------------------------
# 停止結果ログ
# ------------------------------------------------------------
$StopTime = Get-Date


$StopLogLines = @(
    "StopTime=$($StopTime.ToString('yyyy-MM-dd HH:mm:ss'))"
    'Result=Stopped'
    "SampleCount=$($Summary.SampleCount)"
    "CounterCount=$CounterCount"
    "CsvPath=$($ConversionResult.CsvPath)"
)


Add-LogLines `
    -Path $State.LogPath `
    -Lines $StopLogLines


# ------------------------------------------------------------
# 一時ファイル削除
# ------------------------------------------------------------
foreach (
    $TemporaryFile in
        $State.StopRequestFile,
        $State.ReadyFile,
        $State.StandardOutputPath,
        $State.StandardErrorPath,
        $StateFile
) {
    Remove-Item `
        -LiteralPath $TemporaryFile `
        -Force `
        -ErrorAction SilentlyContinue
}


# ------------------------------------------------------------
# 処理結果
# ------------------------------------------------------------
[PSCustomObject]@{
    Result       = 'Stopped'
    TestId       = $State.TestId
    StartTime    = $State.StartTime
    StopTime     = $StopTime.ToString('yyyy-MM-dd HH:mm:ss')
    SampleCount  = $Summary.SampleCount
    CounterCount = $CounterCount
    BlgPath      = $State.BlgPath
    CsvPath      = $ConversionResult.CsvPath
    DataRows     = $ConversionResult.DataRows
    ColumnCount  = $ConversionResult.ColumnCount
    LogPath      = $State.LogPath
}
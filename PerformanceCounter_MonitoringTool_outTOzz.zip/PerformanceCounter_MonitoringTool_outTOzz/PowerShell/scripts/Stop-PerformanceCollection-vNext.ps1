# Stop-PerformanceCollection-vNext.ps1

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$LogDirectory = Join-Path $ProjectRoot 'logs'
$StateFile = Join-Path $LogDirectory 'collection-state.json'

if (-not (Test-Path $StateFile))
{
    throw "State file not found."
}

$State = Get-Content $StateFile -Raw |
    ConvertFrom-Json

Set-Content `
    -LiteralPath $State.StopRequestFile `
    -Value 'Stop' `
    -Encoding ASCII

Write-Host "Stop requested."
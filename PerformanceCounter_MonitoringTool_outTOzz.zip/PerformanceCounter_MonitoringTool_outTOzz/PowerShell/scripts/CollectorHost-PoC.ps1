param(
    [Parameter(Mandatory = $true)]
    [string]$CounterFile,

    [Parameter(Mandatory = $true)]
    [string]$ReadyFile
)

$ErrorActionPreference = 'Stop'

$Counters = @(
    Get-Content -LiteralPath $CounterFile |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ }
)

$sw = [System.Diagnostics.Stopwatch]::StartNew()

Get-Counter `
    -Counter $Counters `
    -SampleInterval 1 `
    -Continuous `
    -ErrorAction Stop |
    ForEach-Object {

        Set-Content `
            -LiteralPath $ReadyFile `
            -Value 'READY' `
            -Encoding ASCII

        Write-Host ''
        Write-Host 'FIRST SAMPLE:'
        Write-Host $sw.Elapsed.TotalSeconds
        Write-Host ''

        break
    }
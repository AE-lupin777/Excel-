param(
    [Parameter(Mandatory = $true)]
    [string]$CounterFile,

    [Parameter(Mandatory = $true)]
    [string]$BlgPath,

    [Parameter(Mandatory = $true)]
    [string]$StopRequestFile,

    [Parameter(Mandatory = $true)]
    [string]$ReadyFile,

    [ValidateRange(1, 3600)]
    [int]$SampleInterval = 1
)

$ErrorActionPreference = 'Stop'

$CollectorPowerShell = $null
$AsyncResult = $null
$StopWasRequested = $false

try {
    $Counters = @(
        Get-Content -LiteralPath $CounterFile |
            ForEach-Object { $_.Trim() } |
            Where-Object { $_ }
    )

    if ($Counters.Count -eq 0) {
        throw "No usable counters were found: $CounterFile"
    }

    Remove-Item -LiteralPath $ReadyFile -Force -ErrorAction SilentlyContinue

    $CollectorScript = @'
param(
    [string[]]$JobCounters,
    [string]$OutputPath,
    [string]$ReadyPath,
    [int]$Interval
)

$ErrorActionPreference = 'Stop'
$ReadySent = $false

Get-Counter `
    -Counter $JobCounters `
    -SampleInterval $Interval `
    -Continuous `
    -ErrorAction Stop |
    ForEach-Object {
        if (-not $ReadySent) {
            Set-Content `
                -LiteralPath $ReadyPath `
                -Value 'Ready' `
                -Encoding ASCII

            $ReadySent = $true
        }

        $_
    } |
    Export-Counter `
        -Path $OutputPath `
        -FileFormat BLG `
        -Force `
        -ErrorAction Stop
'@

    $CollectorPowerShell = [PowerShell]::Create()

    [void]$CollectorPowerShell.
        AddScript($CollectorScript).
        AddArgument([string[]]$Counters).
        AddArgument($BlgPath).
        AddArgument($ReadyFile).
        AddArgument($SampleInterval)

    $AsyncResult = $CollectorPowerShell.BeginInvoke()

    $ReadyDeadline = (Get-Date).AddSeconds(15)

    while ((Get-Date) -lt $ReadyDeadline) {
        if ($AsyncResult.IsCompleted) {
            [void]$CollectorPowerShell.EndInvoke($AsyncResult)
            throw 'Collector pipeline stopped before startup completed.'
        }

        if (Test-Path -LiteralPath $ReadyFile -PathType Leaf) {
            break
        }

        Start-Sleep -Milliseconds 100
    }

    if (-not (Test-Path -LiteralPath $ReadyFile -PathType Leaf)) {
        throw 'Timed out while starting performance counter collection.'
    }

    while (-not (Test-Path -LiteralPath $StopRequestFile -PathType Leaf)) {
        if ($AsyncResult.IsCompleted) {
            [void]$CollectorPowerShell.EndInvoke($AsyncResult)
            throw 'Collector pipeline stopped unexpectedly.'
        }

        Start-Sleep -Milliseconds 250
    }

    $StopWasRequested = $true
}
finally {
    if ($null -ne $CollectorPowerShell) {
        if ($null -ne $AsyncResult -and -not $AsyncResult.IsCompleted) {
            $CollectorPowerShell.Stop()
        }

        if ($null -ne $AsyncResult) {
            try {
                [void]$CollectorPowerShell.EndInvoke($AsyncResult)
            }
            catch [System.Management.Automation.PipelineStoppedException] {
                if (-not $StopWasRequested) {
                    throw
                }
            }
        }

        $CollectorPowerShell.Dispose()
    }
}
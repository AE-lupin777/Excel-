$Counters = Get-Content ..\config\counters.effective.txt

$ReadyFile = "$env:TEMP\runspace2.ready"

Remove-Item $ReadyFile -ErrorAction SilentlyContinue

$sw = [System.Diagnostics.Stopwatch]::StartNew()

$CollectorScript = @'
param(
    [string[]]$JobCounters,
    [string]$ReadyPath
)

$ReadySent = $false

Get-Counter `
    -Counter $JobCounters `
    -SampleInterval 1 `
    -Continuous `
    -ErrorAction Stop |
    ForEach-Object {

        if (-not $ReadySent) {

            Set-Content `
                -LiteralPath $ReadyPath `
                -Value 'Ready' `
                -Encoding ASCII

            $ReadySent = $true
        }

        $_

        break
    }
'@

$ps = [PowerShell]::Create()

[void]$ps.
    AddScript($CollectorScript).
    AddArgument([string[]]$Counters).
    AddArgument($ReadyFile)

$r = $ps.BeginInvoke()

while (-not (Test-Path $ReadyFile)) {
    Start-Sleep -Milliseconds 10
}

$sw.Elapsed.TotalSeconds

$ps.Stop()
$ps.Dispose()
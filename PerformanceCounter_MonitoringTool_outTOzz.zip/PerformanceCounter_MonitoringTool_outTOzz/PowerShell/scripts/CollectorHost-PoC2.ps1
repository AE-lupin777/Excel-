param(
    [Parameter(Mandatory = $true)]
    [string]$CounterFile,

    [Parameter(Mandatory = $true)]
    [string]$ReadyFile,

    [Parameter(Mandatory = $true)]
    [string]$StartFile,

    [Parameter(Mandatory = $true)]
    [string]$StopFile
)

$ErrorActionPreference = 'Stop'

$Counters = @(
    Get-Content -LiteralPath $CounterFile |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ }
)

Set-Content `
    -LiteralPath $ReadyFile `
    -Value 'HOST_READY' `
    -Encoding ASCII

Write-Host 'HOST_READY'

while ($true) {

    while (-not (Test-Path $StartFile)) {
        Start-Sleep -Milliseconds 100
    }

    Remove-Item $StartFile -Force

    $sw = [System.Diagnostics.Stopwatch]::StartNew()

    Get-Counter `
        -Counter $Counters `
        -SampleInterval 1 `
        -Continuous |
        ForEach-Object {

            Write-Host ''
            Write-Host 'COLLECT_READY'
            Write-Host $sw.Elapsed.TotalSeconds
            Write-Host ''

            break
        }

    while (-not (Test-Path $StopFile)) {
        Start-Sleep -Milliseconds 100
    }

    Remove-Item $StopFile -Force
}
# vNext Impact Analysis

## 調査結果

RunspaceWorker-PoC

1.1269419 sec

### 現行

Start-PerformanceCollection

7〜9 sec

### 差分

Invoke-PerformanceCollector.ps1 は
既に PowerShell.Create() を使用している。

## Stop処理調査

WorkerProcessId の利用箇所

- Get-Process
- Wait-Process

のみ

確認済み。

## 影響範囲

変更対象

- Start-PerformanceCollection.ps1
- Stop-PerformanceCollection.ps1

非変更対象

- Convert-PerformanceLog.ps1
- BLG
- CSV
- Ready
- Stop
- StateFile構造
- Counter設定

## 方針

Invoke-PerformanceCollector.ps1 は維持。

Worker起動方式のみ見直す。
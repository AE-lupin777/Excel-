# Runspace Migration Plan

## 現状

Start-PerformanceCollection.ps1

↓

Start-Process

↓

powershell.exe

↓

Invoke-PerformanceCollector.ps1

↓

Get-Counter

↓

Ready

## 実測結果

### 現行

Ready

7～9秒

### RunspaceWorker-PoC

Ready

1.088675秒

## 考察

Get-Counter自体がボトルネックではない。

Start-Process により新規 powershell.exe を起動し、
Invoke-PerformanceCollector.ps1 を実行する経路が
主要な起動遅延要因である可能性が高い。

## 方針

Invoke-PerformanceCollector.ps1 は変更しない。

Start-PerformanceCollection.ps1 の

Start-Process

部分を

Runspace実行に置き換えるPoCを実施する。

## 非変更対象

- Invoke-PerformanceCollector.ps1
- Stop-PerformanceCollection.ps1
- Setup-PerformanceCollection.ps1
- collection-state.json
- Ready
- Stop
- BLG
- CSV

## 変更対象

- Start-PerformanceCollection.ps1

Worker起動部分のみ


# Stop処理確認結果

Stop-PerformanceCollection.ps1 は

WorkerProcessId

を利用している。

そのため、

Start-Process を単純に Runspace 化すると
Stop 処理との整合が取れなくなる。

Runspace 移行を行う場合は

- WorkerProcessId管理
- Stop処理
- Wait-Process

の再設計が必要。
# Investigation Conclusion

## 結論

起動時間の主要因は Get-Counter 本体ではない。

以下を確認済み。

### RunspaceWorker-PoC

1.1269419 sec

### RunspaceWorker-PoC2

1.0919117 sec

### RunspaceWorker-PoC3

1.1485078 sec

### Invoke-PerformanceCollector.ps1

7.3915726 sec

## 判定

Get-Counter

Ready生成

Export-Counter

Runspace

は単独では約1秒程度で動作する。

一方、

Invoke-PerformanceCollector.ps1 を

powershell.exe -File

経由で起動すると約7秒を要する。

## 方針

追加調査は終了。

次フェーズは

vNext設計

とする。

## vNext目標

Ready

7〜9秒

↓

1〜2秒
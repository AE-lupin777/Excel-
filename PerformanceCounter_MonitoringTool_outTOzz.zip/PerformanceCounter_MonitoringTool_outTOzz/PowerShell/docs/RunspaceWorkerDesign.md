# Runspace Worker Design

## 目的

Worker起動時間短縮

現行

Start-Process
↓
powershell.exe
↓
Invoke-PerformanceCollector.ps1

約7～9秒

PoC

PowerShell.Create()
↓
Runspace
↓
Get-Counter

約1.1秒

## 方針

Invoke-PerformanceCollector.ps1 の処理は変更しない。

Start-PerformanceCollection.ps1 の

Start-Process

部分のみ置き換える。

## 現行

Start

↓

Start-Process

↓

powershell.exe

↓

Invoke-PerformanceCollector.ps1

↓

Ready

## 改修案

Start

↓

PowerShell.Create()

↓

Runspace

↓

Invoke-PerformanceCollector処理

↓

Ready

## 変更対象

Start-PerformanceCollection.ps1

Worker起動箇所のみ

## 非変更対象

- Invoke-PerformanceCollector.ps1
- Stop-PerformanceCollection.ps1
- Setup-PerformanceCollection.ps1
- BLG出力
- CSV出力
- Ready
- Stop
- StateFile

## メリット

変更範囲最小

既存資産活用可能

起動時間改善期待

## リスク

WorkerProcessId管理方法の見直しが必要

Stop処理との整合確認が必要
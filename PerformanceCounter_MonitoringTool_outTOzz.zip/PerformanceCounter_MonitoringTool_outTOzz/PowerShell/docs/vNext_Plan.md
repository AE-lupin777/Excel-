# vNext Plan

## 方針

既存機能は維持する。

以下は変更しない。

- Stop-PerformanceCollection.ps1
- Convert-PerformanceLog.ps1
- BLG
- CSV
- Ready
- Stop
- collection-state.json

## PoC結果

ULVAC側PC

RunspaceWorker-PoC

1.1269419 sec

## 仮説

Start-Process による Worker起動経路に
主要な起動遅延が存在する可能性が高い。

## 次Phase

Invoke-PerformanceCollector 相当機能を
Runspaceへ埋め込む PoC を作成する。

## 成功条件

Ready

2秒以内
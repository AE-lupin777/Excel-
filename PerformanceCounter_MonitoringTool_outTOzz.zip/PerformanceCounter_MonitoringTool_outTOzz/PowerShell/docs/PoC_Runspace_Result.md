# Runspace PoC 実施結果

## 目的

起動時間（Ready生成まで約8秒）の原因が

・Get-Counterそのもの

なのか

・Worker起動方式

なのかを切り分ける。

---

## 現行構成

Start-PerformanceCollection.ps1

↓

新規 powershell.exe

↓

Invoke-PerformanceCollector.ps1

↓

Get-Counter

↓

Export-Counter

↓

Ready生成

---

## 測定結果

### 現行構成

Start-PerformanceCollection.ps1

約7～9秒

---

Invoke-PerformanceCollector.ps1

約7～8秒

---

### 同一 PowerShell セッション

Get-Counter | Out-Null

約1.08秒

---

### Runspace

PowerShell.Create()

↓

Get-Counter | Out-Null

約1.10秒

---

### CollectorHost-PoC

Get-Counter 初回サンプル到達

約2.55秒

---

## 考察

Get-Counterそのものの実行時間は約1秒である。

一方で、

新規 powershell.exe プロセスから
Get-Counter を利用する経路では
約7～9秒を要する。

このため、

起動遅延の主要因は

「Get-Counterそのもの」

ではなく、

「Worker起動方式」

である可能性が高い。

---

## 結論

Runspaceを利用した場合は
約1秒で実行できることを確認した。

現行構成の

Start-Process
↓
powershell.exe
↓
Invoke-PerformanceCollector

の経路を見直すことで
起動時間改善の可能性がある。

---

## 次回予定

Start-Process を使用せず

Runspaceで
Invoke-PerformanceCollector 相当の処理を実行する
PoCを実施する。


## RunspaceWorker-PoC

計測結果

1.088675秒

### 考察

Runspace上で実行した場合は
Get-Counter単体実行と同等の性能で動作した。

Start-Process による
新規 powershell.exe 起動経路が
起動遅延の主原因である可能性が高い。
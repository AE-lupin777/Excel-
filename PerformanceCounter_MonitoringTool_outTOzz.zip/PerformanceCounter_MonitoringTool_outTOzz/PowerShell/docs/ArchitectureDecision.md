# Architecture Decision

## 採用しない案

Worker全面Runspace化

理由

Stop-PerformanceCollection.ps1 が
WorkerProcessIdに依存しているため。

改修範囲が大きい。

---

## 採用候補

Workerプロセスは維持する。

Invoke-PerformanceCollector.ps1 の
起動方法を変更する。

---

## 根拠

Runspace PoC

1.088675秒

現行 Worker

7～9秒

改善余地あり。
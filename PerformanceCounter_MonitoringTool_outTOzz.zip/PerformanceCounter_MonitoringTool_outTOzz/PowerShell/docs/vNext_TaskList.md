# vNext Task List

## 完了

- 原因調査
- Runspace PoC
- ULVAC実機確認

## 次

### Task-01

Runspace Worker版 Start作成

新規

Start-PerformanceCollection-vNext.ps1

### Task-02

Ready確認

目標

1～2秒

### Task-03

BLG出力確認

### Task-04

Stop対応

### Task-05

CSV変換確認

### Task-06

連続試験
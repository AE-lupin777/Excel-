@echo off
setlocal
cd /d "%~dp0"
if /i "%~1"=="sender" (set "ROLE=sender"& set "PROCESS_NAME=ULAgent.Sender"& goto role_ok)
if /i "%~1"=="receiver" (set "ROLE=receiver"& set "PROCESS_NAME=ULAgent.Receiver"& goto role_ok)
echo Usage: Initialize-PerformanceCollection.cmd sender ^| receiver
pause
exit /b 2
:role_ok
if not exist "%~dp0config" mkdir "%~dp0config"
>"%~dp0config\role.conf" echo %ROLE%
set "SELFTEST_STATUS=Not run"
set "POWERSHELL_HOST=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "PWSH_HOST="
for /f "delims=" %%I in ('where pwsh.exe 2^>nul') do if not defined PWSH_HOST set "PWSH_HOST=%%I"
if defined PWSH_HOST set "POWERSHELL_HOST=%PWSH_HOST%"
echo Role: %ROLE%
echo Process: %PROCESS_NAME%
echo PowerShell host: %POWERSHELL_HOST%
echo [1/3] Unblocking PowerShell scripts...
"%POWERSHELL_HOST%" -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' -Recurse -Filter '*.ps1' -File | ForEach-Object { Unblock-File -LiteralPath $_.FullName }"
if errorlevel 1 goto error
echo [2/3] Running setup...
"%POWERSHELL_HOST%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Setup-PerformanceCollection.ps1"
if errorlevel 1 goto error
echo [3/3] Checking whether self-test is required...
"%POWERSHELL_HOST%" -NoProfile -ExecutionPolicy Bypass -Command "if (Get-Process -Name '%PROCESS_NAME%' -ErrorAction SilentlyContinue) { exit 0 } else { exit 10 }"
if errorlevel 11 goto error
if errorlevel 10 goto run_self_test
if errorlevel 1 goto error
set "SELFTEST_STATUS=Skipped (real %PROCESS_NAME% is running)"
echo [3/3] Real %PROCESS_NAME% detected. Self-test skipped normally.
goto success
:run_self_test
echo [3/3] %PROCESS_NAME% not found. Running self-test...
"%POWERSHELL_HOST%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Test-PerformanceCollection.ps1" -Role "%ROLE%" -KeepArtifacts
if errorlevel 1 goto error
set "SELFTEST_STATUS=Completed"
:success
echo.
echo ========================================
echo Setup completed successfully.
echo Role: %ROLE%
echo Process: %PROCESS_NAME%
echo Self-test: %SELFTEST_STATUS%
echo ========================================
pause
exit /b 0
:error
echo.
echo ========================================
echo ERROR: Initialization failed.
echo ========================================
pause
exit /b 1

# CollectorHost PoC

## 目的

Get-Counter初回呼び出しによる約8秒の遅延が、
Worker常駐方式で改善するか確認する。

## 現状

試験開始毎に

powershell.exe

↓

Get-Counter

を実行している。

計測結果

Ready
約7〜9秒

## PoC

CollectorHostを常駐させる。

Setup後

CollectorHost起動

↓

HOST_READY

↓

Start要求

↓

収集開始

↓

Stop要求

↓

収集停止

↓

次試験

↓

収集開始

## 判定

試験1回目

起動時間は評価対象外

試験2回目以降

Ready相当が1〜2秒以内になることを期待する
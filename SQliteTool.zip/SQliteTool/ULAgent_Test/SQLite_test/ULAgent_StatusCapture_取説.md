# ULAgent 状態・履歴取得ツール 取扱説明書

## 1. このツールでできること

ULAgent の **Sender（送信側）** または **Receiver（受信側）** の状態と履歴情報を、ボタン操作に近い簡単な手順で取得し、ファイルに保存するツールです。

- ツールを起動した時点の情報を **1回だけ** 取得します。
- 取得結果は `Evidence` フォルダ内に保存されます（標準設定の場合）。
- 取得した情報を CSV ファイルで確認できます。
- 自動的に連続取得するツールではありません。再度取得する場合は、もう一度起動してください。

> **重要**：このツールは ULAgent が動いている **同じWindows PC** で実行してください。送信側と受信側が別々のPCの場合は、それぞれのPCで実行します。

## 2. 使用前に確認すること

1. 取得したい PC で ULAgent の Sender または Receiver が起動していることを確認します。
2. 次の3ファイルが同じフォルダにあることを確認します。
   - `ULAgent_StatusCapture.bat`（起動用）
   - `Capture-ULAgentStatus.ps1`（情報取得用）
   - `ULAgent_StatusCapture.ini`（接続先・保存先の設定用）
3. 取得する対象が **Sender** か **Receiver** かを確認します。
4. Windows の PowerShell が利用できる環境で実行します。

**注意**：`Capture-ULAgentStatus.ps1` や `ULAgent_StatusCapture.ini` のファイル名は変更しないでください。

## 3. 最初の設定（Sender・Receiverの切り替え）

通常は、利用するPCの種類に合わせて **`ULAgent_StatusCapture.ini`** を設定します。メモ帳で開き、次の3項目を確認してください。

### Sender（送信側）PCの場合

```ini
Target=Sender
BaseUrl=http://127.0.0.1:5080
RecordsPath=/api/transfers
Limit=500
OutputDirectory=Evidence
```

### Receiver（受信側）PCの場合

```ini
Target=Receiver
BaseUrl=http://127.0.0.1:5081
RecordsPath=/api/receives
Limit=500
OutputDirectory=Evidence
```

設定後は **上書き保存** して、メモ帳を閉じてください。

> 同梱の `ULAgent_StatusCapture_recv.ini` は Receiver 用の設定例です。こちらを使用する場合は、既存の `ULAgent_StatusCapture.ini` をバックアップしたうえで、Receiver用設定ファイルの内容を `ULAgent_StatusCapture.ini` に反映してください。**`_recv.ini` のままでは起動時に読み込まれません。**

通常は `Limit=500`、`OutputDirectory=Evidence` のままで構いません。接続先やポート番号が標準構成と異なる場合は、システム管理者に確認してください。

## 4. 情報を取得する手順

1. エクスプローラーで `SQLite_test` フォルダを開きます。
2. **`ULAgent_StatusCapture.bat`** をダブルクリックします。
3. 黒い画面に次の入力案内が表示されます。

   ```text
   Enter Test ID (e.g. 1-1-1)
   ```

4. 作業で指定された **テストID**（例：`1-1-1`）を入力し、**Enter** キーを押します。
5. 画面に `Target`（取得対象）、`URL`（接続先）、`Output`（保存先）が表示されます。
6. 情報取得が終わると、次の成功メッセージが表示されます。

   ```text
   Capture completed successfully.
   Records: 取得件数
   ```

7. 最後に表示される `Press any key to continue . . .`（キーを押してください）の案内に従って画面を閉じます。
8. 次章の方法で保存ファイルを確認します。

**注意**：テストIDの入力は必須です。空欄のまま Enter を押すと処理は開始されません。テストIDには `1-1-1` のような半角英数字とハイフンを使用し、`\ / : * ? " < > |` などの記号は使わないでください。

## 5. 取得結果を確認する方法

標準設定では、ツールのある `SQLite_test` フォルダ内に **`Evidence`** フォルダが作成されます。

その中に、実行ごとのフォルダが作成されます。

```text
SQLite_test
├─ ULAgent_StatusCapture.bat
├─ Capture-ULAgentStatus.ps1
├─ ULAgent_StatusCapture.ini
└─ Evidence
   └─ 1-1-1_20261102_103000_PC名_Sender
      ├─ all_results.json
      ├─ records.json
      ├─ execution_info.csv
      ├─ status.csv
      └─ records.csv
```

※ フォルダ名は「テストID_取得開始日時_PC名_対象」の形式です。上記は説明用の例です。

| ファイル名 | 内容・用途 |
|---|---|
| `execution_info.csv` | 取得開始・完了日時、PC名、取得対象、取得件数などを確認 |
| `status.csv` | ULAgent の状態情報を確認 |
| `records.csv` | Sender の送信履歴、または Receiver の受信履歴を確認 |
| `all_results.json` | 取得した情報一式をまとめたファイル（詳細確認・保管用） |
| `records.json` | 履歴データのファイル（詳細確認・保管用） |

**確認の目安**：まず `execution_info.csv` を開いて対象PCや取得日時が正しいことを確認し、必要に応じて `status.csv` と `records.csv` を確認してください。

`Records: 0` と表示された場合でも、**取得処理自体は成功している場合があります**。この場合、`records.csv` には `No records were returned.` と記録されます。0件の理由までは、このツールだけでは判断できません。

## 6. うまく取得できなかった場合

画面に次のように表示された場合は、情報取得に失敗しています。

```text
Capture failed.
Error file: 保存先
```

エラー内容は、標準では `SQLite_test\Evidence` に作成される **`ERROR_日時.txt`** に保存されます。エラーのあった実行では、通常の5種類の結果ファイルがそろわない場合があります。

| 状況 | 確認・対応方法 |
|---|---|
| `Test ID is required.` | テストIDが空欄です。再起動して入力してください。 |
| `INI file not found` | `ULAgent_StatusCapture.ini` が同じフォルダにあるか確認してください。 |
| `Required INI setting is missing` | INIの必須項目が空欄・未記入です。第3章の設定を確認してください。 |
| `Limit must be between 1 and 500.` | INIの `Limit` を1～500の整数に設定してください。 |
| 接続できない・タイムアウトになる | 正しいPCで実行しているか、対象ULAgentが起動しているか、Sender／Receiverの設定が合っているかを確認してください。 |
| 保存先にファイルが見つからない | 実行画面の `Output` に表示されたフォルダ、または `Evidence` 内を確認してください。 |

解決しないときは、**テストID・実行日時・対象（Sender／Receiver）・エラーファイル**を控え、管理者に連絡してください。設定内容が分からない場合は、自己判断でURLやポート番号を変更しないでください。

## 7. 使用上の注意

- このツールは情報を **参照して保存する目的** のものです。ULAgent の状態や履歴を変更する操作は行いません。
- 毎回別の実行結果フォルダを作成するため、繰り返し実行すると保存データが増えます。削除・整理は管理者の指示に従ってください。
- 取得履歴の最大件数は **500件** です（`Limit` の設定範囲は1～500）。すべての過去履歴を必ず取得できるわけではありません。
- Sender／Receiver の切り替えは自動ではありません。**取得する前にINIを確認**してください。
- CSVやJSONには運用情報・ファイル名などが含まれる可能性があります。社外共有や外部サービスへのアップロードは行わず、管理ルールに従って保管してください。
- `appsettings.json` や `receiver_state.db` などのULAgent関連ファイルは、この取扱手順で編集しないでください。

---

### 付記（確認範囲）

本説明書は提供された `SQLite_test` 内の BAT、PowerShell、INI、既存READMEを確認して作成しました。実機での動作検証、お客様環境におけるサービス稼働確認は行っていません。表示される履歴の各項目の業務上の意味は、ULAgent 本体の仕様に従います。

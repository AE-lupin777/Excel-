param(
    [Parameter(Mandatory = $true)][string]$TestId,
    [ValidateRange(1, 3600)][int]$SampleInterval = 1
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'HostCommon.ps1')
$Watch = [Diagnostics.Stopwatch]::StartNew()
if ([string]::IsNullOrWhiteSpace($TestId)) { throw 'TestId must not be empty.' }
if ($TestId.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0) { throw "Invalid TestId: $TestId" }

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$LogDirectory = Join-Path $ProjectRoot 'logs'
$OutputDirectory = Join-Path $ProjectRoot 'output'
$CounterFile = Join-Path $ProjectRoot 'config\counters.effective.txt'
$StateFile = Join-Path $LogDirectory 'collection-state.json'
$HostStateFile = Join-Path $LogDirectory 'collector-host.json'
$HostStarter = Join-Path $PSScriptRoot 'Start-CollectorHost.ps1'
$RequestFile = Join-Path $LogDirectory 'collector-request.json'
$WindowsPowerShell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

foreach ($Directory in $LogDirectory, $OutputDirectory) { New-Item -ItemType Directory -Path $Directory -Force | Out-Null }
if (Test-Path -LiteralPath $StateFile -PathType Leaf) { throw "Collection state already exists: $StateFile" }
if (Test-Path -LiteralPath $RequestFile -PathType Leaf) { throw "Collector request already exists: $RequestFile" }
if (-not (Test-Path -LiteralPath $CounterFile -PathType Leaf)) { throw "Counter file not found: $CounterFile" }
$Counters = @(Get-Content -LiteralPath $CounterFile | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') })
if ($Counters.Count -eq 0) { throw 'No effective counters were found.' }

$HostResult = & $HostStarter
$HostState = Get-Content -LiteralPath $HostStateFile -Raw | ConvertFrom-Json
$HostIdentity = Get-CollectorHostIdentityResult -HostState $HostState -ExpectedExecutablePath $WindowsPowerShell
if (-not $HostIdentity.IsValid) { throw "CollectorHost identity validation failed before Start: $($HostIdentity.Reason)" }

$StartTime = Get-Date
$Timestamp = $StartTime.ToString('yyyyMMdd_HHmmss')
$RunId = [Guid]::NewGuid().ToString('N')
$ArtifactBase = "${TestId}_${Timestamp}_${RunId}"
$BlgPath = Join-Path $OutputDirectory "$ArtifactBase.blg"
$LogPath = Join-Path $LogDirectory "$ArtifactBase.log"
$ReadyFile = Join-Path $LogDirectory "collector-$RunId.ready"
$StopFile = Join-Path $LogDirectory "collector-$RunId.stop"
$CompletedFile = Join-Path $LogDirectory "collector-$RunId.completed.json"
$ErrorFile = Join-Path $LogDirectory "collector-$RunId.error.log"

$State = [PSCustomObject]@{
    Scheme='PersistentCollectorRunV2'; Status='StartPending'; TestId=$TestId; RunId=$RunId
    HostId=[string]$HostState.HostId; WorkerProcessId=[int]$HostState.ProcessId
    HostProcessStartTimeUtcTicks=[Int64]$HostState.ProcessStartTimeUtcTicks
    StartTime=$StartTime.ToString('o'); LastTransitionTime=(Get-Date).ToString('o'); LastError=$null
    StopTime=$null; HostCompletionStatus=$null; SampleCount=$null; DataRows=$null; ColumnCount=$null; CsvPath=$null
    SampleInterval=$SampleInterval; CounterCount=$Counters.Count; BlgPath=$BlgPath; LogPath=$LogPath
    ReadyFile=$ReadyFile; StopFile=$StopFile; CompletedFile=$CompletedFile; ErrorFile=$ErrorFile
    TerminalStateFile=(Join-Path $LogDirectory "collector-run-$RunId.final.json")
}
Write-JsonAtomic -Value $State -Path $StateFile

$Request = [PSCustomObject]@{
    Scheme='CollectorRunRequestV2'; HostId=$State.HostId; RunId=$RunId; CounterFile=$CounterFile
    BlgPath=$BlgPath; ReadyFile=$ReadyFile; StopFile=$StopFile; CompletedFile=$CompletedFile
    ErrorFile=$ErrorFile; SampleInterval=$SampleInterval; RequestTime=(Get-Date).ToString('o')
}
Write-JsonAtomic -Value $Request -Path $RequestFile

try {
    $Deadline = (Get-Date).AddSeconds(20)
    while ((Get-Date) -lt $Deadline) {
        if (Test-Path -LiteralPath $ReadyFile -PathType Leaf) {
            $Ready = Get-Content -LiteralPath $ReadyFile -Raw | ConvertFrom-Json
            if ($Ready.Scheme -eq 'CollectorRunReadyV2' -and [string]$Ready.RunId -eq $RunId) { break }
            throw 'Ready file identity does not match the requested run.'
        }
        if (Test-Path -LiteralPath $CompletedFile -PathType Leaf) {
            $EarlyCompletion = Get-Content -LiteralPath $CompletedFile -Raw | ConvertFrom-Json
            throw "Collector completed before Ready. Status: $($EarlyCompletion.Status); Error: $($EarlyCompletion.Error)"
        }
        $CurrentHostState = Get-Content -LiteralPath $HostStateFile -Raw | ConvertFrom-Json
        $CurrentIdentity = Get-CollectorHostIdentityResult -HostState $CurrentHostState -ExpectedExecutablePath $WindowsPowerShell
        if (-not $CurrentIdentity.IsValid -or [string]$CurrentHostState.HostId -ne $State.HostId) {
            throw "CollectorHost identity changed during Start: $($CurrentIdentity.Reason)"
        }
        Start-Sleep -Milliseconds 100
    }
    if (-not (Test-Path -LiteralPath $ReadyFile -PathType Leaf)) { throw 'Timed out while waiting for the first counter sample.' }

    $State.Status = 'Running'
    $State.LastTransitionTime = (Get-Date).ToString('o')
    Write-JsonAtomic -Value $State -Path $StateFile
    $Watch.Stop()
    @(
        'Result=Started'; 'LifecycleStatus=Running'; "TestId=$TestId"; "RunId=$RunId"; "HostId=$($State.HostId)"
        "StartTime=$($State.StartTime)"; "WorkerProcessId=$($State.WorkerProcessId)"; "SampleInterval=$SampleInterval"
        "CounterCount=$($Counters.Count)"; "BlgPath=$BlgPath"; "StartTotalSeconds=$([Math]::Round($Watch.Elapsed.TotalSeconds, 3))"
        'ReadyDefinition=collector pipeline emitted its first sample'
    ) | Set-Content -LiteralPath $LogPath -Encoding UTF8

    [PSCustomObject]@{
        Result='Started'; LifecycleStatus='Running'; TestId=$TestId; RunId=$RunId; HostId=$State.HostId
        ProcessId=$State.WorkerProcessId; CounterCount=$Counters.Count; SampleInterval=$SampleInterval
        BlgPath=$BlgPath; StartTotalSeconds=[Math]::Round($Watch.Elapsed.TotalSeconds,3); StateFile=$StateFile; LogPath=$LogPath
    }
}
catch {
    $OriginalFailure = $_.Exception.ToString()
    $State.Status = 'StartFailedCleanupRequested'
    $State.LastError = $OriginalFailure
    $State.LastTransitionTime = (Get-Date).ToString('o')
    Write-JsonAtomic -Value $State -Path $StateFile
    Write-JsonAtomic -Value ([PSCustomObject]@{Scheme='CollectorRunStopV2';HostId=$State.HostId;RunId=$RunId;Reason='StartFailed';Time=(Get-Date).ToString('o')}) -Path $StopFile

    $CleanupConfirmed = $false
    $CleanupDeadline = (Get-Date).AddSeconds(20)
    while ((Get-Date) -lt $CleanupDeadline) {
        if (Test-Path -LiteralPath $CompletedFile -PathType Leaf) {
            try {
                $Completion = Get-Content -LiteralPath $CompletedFile -Raw | ConvertFrom-Json
                if ([string]$Completion.RunId -eq $RunId -and [string]$Completion.HostId -eq $State.HostId) { $CleanupConfirmed = $true; break }
            }
            catch { }
        }
        if (-not (Test-Path -LiteralPath $HostStateFile -PathType Leaf)) { break }
        $CurrentHostState = Get-Content -LiteralPath $HostStateFile -Raw | ConvertFrom-Json
        $CurrentIdentity = Get-CollectorHostIdentityResult -HostState $CurrentHostState -ExpectedExecutablePath $WindowsPowerShell
        if (-not $CurrentIdentity.IsValid) { break }
        Start-Sleep -Milliseconds 100
    }

    if ($CleanupConfirmed) {
        $State.Status = 'StartFailedCleaned'
        $State.HostCompletionStatus = [string]$Completion.Status
        $State.LastTransitionTime = (Get-Date).ToString('o')
        Write-TerminalRunState -State $State -LogDirectory $LogDirectory | Out-Null
        @('Result=StartFailed','LifecycleStatus=StartFailedCleaned',"TestId=$TestId","RunId=$RunId","Failure=$OriginalFailure") | Set-Content -LiteralPath $LogPath -Encoding UTF8
        Remove-Item -LiteralPath $RequestFile, $ReadyFile, $StopFile, $CompletedFile, $StateFile -Force -ErrorAction SilentlyContinue
        throw "Start failed and Host cleanup was confirmed. RunId: $RunId. $OriginalFailure"
    }

    $State.Status = 'StartFailureCleanupIncomplete'
    $State.LastTransitionTime = (Get-Date).ToString('o')
    Write-JsonAtomic -Value $State -Path $StateFile
    Write-TerminalRunState -State $State -LogDirectory $LogDirectory | Out-Null
    throw "Start failed and Host cleanup could not be confirmed. State and artifacts were preserved. RunId: $RunId. $OriginalFailure"
}

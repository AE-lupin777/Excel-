# 常駐CollectorHost方式 安全性改善候補

## 位置付け

Windows PowerShell 5.1のCollectorHostをSetup時に起動し、同一Hostを試験ごとに再利用する改善候補です。`Get-Counter`の初回サンプルをReady条件とし、BLG・CSV・TestId・Start／Stopの既存仕様を維持します。

正式採用前の候補であり、`00_Original`、`01_Source`、`02_Diagnostics`は変更していません。

## 操作

```powershell
.\scripts\PerformanceCollection.cmd setup
.\scripts\PerformanceCollection.cmd start TEST_ID
.\scripts\PerformanceCollection.cmd stop
.\scripts\PerformanceCollection.cmd shutdown
```

通常はSetupでHostを起動し、全試験の終了時だけshutdownします。

## 状態管理

- HostはPIDだけでなく、HostId、プロセス起動時刻、実行ファイルパスで識別します。
- Host状態とReadyファイルが不整合でも、生存中の同一Hostを重複起動しません。
- RunIdをBLG、CSV、ログ、要求・完了状態に使用します。
- JSON状態は一時ファイル作成後の置換で更新します。
- Start失敗時は停止要求を送り、Hostの完了状態を確認してからActive状態を整理します。
- 正常終了は`CompletedValidated`、Start失敗後の確認済み整理は`StartFailedCleaned`として記録します。
- Host異常、識別不一致、停止タイムアウトではActive状態・BLG・ログを残します。
- Stopとshutdownは識別情報が一致しないプロセスを終了しません。強制終了も行いません。

## 自動試験

Windows PowerShell 5.1で実行します。

```powershell
.\scripts\Test-PerformanceCollection.ps1 -DurationSeconds 4 -Cycles 2 -KeepArtifacts -ShutdownHost
.\scripts\Test-ErrorPaths.ps1
.\scripts\Test-SafetyStateManagement.ps1
```

安全性試験は、Ready欠落、Host状態不整合、Start失敗後の復旧を個別に検証します。

## 制約

- Windows PowerShell 5.1が必要です。
- 異常終了時の書きかけBLGは保存対象ですが、復旧は保証しません。
- 会社PCの実カウンター、長時間収集、スリープ、ログオフ、セキュリティ製品との組合せは未検証です。
- 会社PCで評価が完了するまで正式版へ置き換えません。

setlocal enabledelayedexpansion

:loop
echo %date%,!time!  >> 20250219_modubus_result.txt

modpoll.exe -a 0 -c 2 -t3:hex -r 605 -1 -m tcp 192.168.8.240 >> 20250219_modubus_result.txt

timeout /t 1 > null


goto loop
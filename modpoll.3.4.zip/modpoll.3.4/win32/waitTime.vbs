
Wscript.sleep(1 * 5 * 1000)

WScript.Quit

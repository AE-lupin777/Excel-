@echo off

python .\src\ThroughputAnalyzer_v1_1.py

pause
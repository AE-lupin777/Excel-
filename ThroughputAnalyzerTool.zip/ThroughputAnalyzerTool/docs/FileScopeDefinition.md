# FileScopeDefinition

## 目的

イベントを試験全体ではなく
対象fileId単位で取得するための定義。

---

## 対象fileId

取得元

Receiver After Snapshot

records.json

---

## 抽出条件

receiveStatus=RECEIVED

または

registrationStatus=REGISTERED

---

## 利用箇所

Throughput

PointMetric

RangeMetric

Viewer

---

## 方針

すべてのイベントは
対象fileIdを基準に取得する。

---

## イベント例

fileId

F0538043...

C_START

Sending

C_END

Receiver durably accepted

G_START

Receiver durably stored

K_START

registration is pending

G_END

receiveStatus=RECEIVED

K_END

registrationStatus=REGISTERED
# EventTimeSource

## 目的

本ドキュメントは EventDefinition.md で定義されたイベントについて、
実際にどのデータソースから時刻を取得するかを定義する。

EventExtractor は本定義を参照してイベント時刻を抽出する。

---

# B_START

取得元

Sender Log

検索条件

```text
Discovered
```

時刻取得

```text
ログ先頭Timestamp
```

---

# C_START

取得元

Sender Log

検索条件

```text
Sending
```

時刻取得

```text
ログ先頭Timestamp
```

---

# C_END

取得元

Sender Log

検索条件

```text
Receiver durably accepted
```

時刻取得

```text
ログ先頭Timestamp
```

---

# G_START

取得元

Receiver Log

検索条件

```text
Receiver durably stored
```

時刻取得

```text
ログ先頭Timestamp
```

---

# K_START

取得元

Receiver Log

検索条件

```text
registration is pending
```

時刻取得

```text
ログ先頭Timestamp
```

備考

```text
G_STARTと同一ログ行から取得可能
```

---

# G_END

取得元

Receiver records.csv

条件

```text
receiveStatus=RECEIVED
```

時刻取得列

```text
updatedAt
```

---

# K_END

取得元

Receiver records.csv

条件

```text
registrationStatus=REGISTERED
```

時刻取得列

```text
updatedAt
```

備考

```text
定例会にて ULsight DB登録完了イベントとして運用することを確認
```

---

# F

取得元

Sender PerformanceCounter CSV

取得方法

```text
指定時刻の近傍サンプル取得
または
指定範囲の集計
```

---

# J

取得元

Receiver PerformanceCounter CSV

取得方法

```text
指定時刻の近傍サンプル取得
または
指定範囲の集計
```

---

# L

取得元

Linux Resource Tool

取得方法

```text
指定時刻の近傍サンプル取得
または
指定範囲の集計
```

---

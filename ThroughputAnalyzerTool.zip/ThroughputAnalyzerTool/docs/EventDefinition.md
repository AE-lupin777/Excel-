# EventDefinition

Version : 1.0

## 目的

本ドキュメントは Evaluation Framework および Viewer で共通利用するイベント定義を管理する。

イベントは Sender Log、Receiver Log、SQLiteTool 出力、PerformanceCounter 出力などから抽出し、ポイント分析および範囲分析の基準点として利用する。

---

# B_START

## 名称

Discovered

## 説明

Sender が送信対象ファイルを検出した時点。

## 取得元

Sender Log

## 検索条件

```text
Discovered
```

## 時刻取得方法

```text
ログ先頭Timestamp
```

## 主な用途

```text
送信対象投入開始
```

---

# C_START

## 名称

Sending

## 説明

Sender がファイル送信を開始した時点。

## 取得元

Sender Log

## 検索条件

```text
Sending
```

## 時刻取得方法

```text
ログ先頭Timestamp
```

## 主な用途

```text
送信開始
転送時間計測開始
```

## エビデンス例

```text
2026-10-15 11:15:31.274 Sending ...
```

---

# C_END

## 名称

Receiver Durably Accepted

## 説明

Sender が Receiver から受信完了応答を受領した時点。

## 取得元

Sender Log

## 検索条件

```text
Receiver durably accepted
```

## 時刻取得方法

```text
ログ先頭Timestamp
```

## 主な用途

```text
転送処理完了
Throughput算出
```

## エビデンス例

```text
2026-10-15 11:15:32.889 Receiver durably accepted ...
```

---

# G_START

## 名称

Receiver Durably Stored

## 説明

Receiver が受信データを永続保存した時点。

## 取得元

Receiver Log

## 検索条件

```text
Receiver durably stored
```

## 時刻取得方法

```text
ログ先頭Timestamp
```

## 主な用途

```text
Receiver保存完了
```

## エビデンス例

```text
Receiver durably stored ...;
registration is pending.
```

## 備考

G_START と K_START は同一ログ行から取得可能。

---

# G_END

## 名称

Receive Complete

## 説明

Receiver管理状態が受信完了状態になった時点。

## 取得元

Receiver records.json

## 条件

```text
receiveStatus=RECEIVED
```

## 時刻取得列

```text
updatedAt
```

## 主な用途

```text
受信完了状態確認
受信処理完了確認
```

## 備考

records.json を Receiver状態管理の正規データソースとする。

EventExtractor は

```text
receiveStatus=RECEIVED
```

のレコードを検索し、

```text
updatedAt
```

をイベント時刻として使用する。

---

# K_START

## 名称

Registration Pending

## 説明

ULsight DB登録待ち状態へ遷移した時点。

## 取得元

Receiver Log

## 検索条件

```text
registration is pending
```

## 時刻取得方法

```text
ログ先頭Timestamp
```

## 主な用途

```text
ULsight DB登録処理開始
```

## 備考

K_START と G_START は同一ログ行から取得可能。

---

# K_END

## 名称

Registration Complete

## 説明

registrationStatus が REGISTERED になった時点。

運用上は ULsight DB登録完了として扱う。

## 取得元

Receiver records.json

## 条件

```text
registrationStatus=REGISTERED
```

## 時刻取得列

```text
updatedAt
```

## 主な用途

```text
ULsight DB登録完了確認
登録処理時間計測
```

## 備考

records.json を Receiver状態管理の正規データソースとする。

EventExtractor は

```text
registrationStatus=REGISTERED
```

のレコードを検索し、

```text
updatedAt
```

をイベント時刻として使用する。

以下の情報も取得可能。

```text
registrationRetryCount
registrationErrorCode
```

---

# F

## 名称

Sender Resource

## 説明

Sender側リソース情報。

## 取得元

PerformanceCounter CSV

## 取得可能項目

```text
CPU Avg
CPU Max

Memory Avg
Memory Max

Disk Avg
Disk Max

Network Avg
Network Max
```

## 利用方法

```text
ポイント分析
範囲分析
```

---

# J

## 名称

Receiver Resource

## 説明

Receiver側リソース情報。

## 取得元

PerformanceCounter CSV

## 取得可能項目

```text
CPU Avg
CPU Max

Memory Avg
Memory Max

Disk Avg
Disk Max

Network Avg
Network Max
```

## 利用方法

```text
ポイント分析
範囲分析
```

---

# L

## 名称

Linux Resource

## 説明

ULsight環境リソース情報。

## 取得元

Linux Resource Tool

## 取得可能項目

```text
CPU Avg
CPU Max

Memory Avg
Memory Max

Disk Avg
Disk Max

Network Avg
Network Max
```

## 利用方法

```text
ポイント分析
範囲分析
```

---

# Receiver records.json

## 目的

Receiver側管理状態取得用の正規データソース。

## 主な保持情報

```text
fileId
receiveStatus
registrationStatus
registrationRetryCount
registrationErrorCode
updatedAt
```

## 利用イベント

```text
G_END
K_END
```

## 方針

EventExtractor は Receiver状態取得時に

```text
records.csv
```

ではなく

```text
records.json
```

を優先利用する。

---

# ポイント分析

指定イベント時点のリソース情報取得。

例

```text
C_START時点
C_END時点
G_START時点
K_END時点
```

取得可能情報

```text
CPU
Memory
Disk
Network
```

---

# 範囲分析

開始イベントと終了イベントを指定し、その区間のリソース情報を分析する。

例

```text
C_START → C_END
```

```text
G_START → G_END
```

```text
K_START → K_END
```

```text
C_START → K_END
```

取得可能情報

```text
CPU Avg / Max
Memory Avg / Max
Disk Avg / Max
Network Avg / Max
Throughput
```

---

# Snapshot

SQLiteTool の出力は Snapshot として扱う。

例

```text
20261015_021353_UJSVR026_Receiver
20261015_021757_UJSVR026_Receiver
```

```text
20261015_111259_UJW230932_Sender
20261015_111651_UJW230932_Sender
```

## Before Snapshot

試験開始前取得分

## After Snapshot

試験終了後取得分

## 利用ルール

```text
G_END
K_END
```

取得時は

```text
Receiver After Snapshot
```

を使用する。

---

# 管理ルール

イベント定義変更時は以下を同時に更新すること。

```text
docs/EventDefinition.md
docs/EventTimeSource.md
src/EventDefinitions.py
src/EventExtractor.py
```

Evaluation Framework および Viewer は本定義を共通利用する。

# Event Selection Rule

## 最初の一致を採用

B_START
C_START
G_START
K_START

## 最後の一致を採用

C_END
G_END
K_END

# Event Scope

## Test Scope

試験全体を対象とするイベント。

例

```text
最初のSending
最後のReceiver durably accepted
```

## File Scope

対象fileIdに対するイベント。

例

```text
fileId

F0538043...
```

について

```text
C_START
Sending

C_END
Receiver durably accepted

G_START
Receiver durably stored

K_END
registrationStatus=REGISTERED
```

## 注意

PointMetric および RangeMetric は
File Scope を対象とする。

EventReportGenerator は
Test Scope と File Scope を分離して出力する。
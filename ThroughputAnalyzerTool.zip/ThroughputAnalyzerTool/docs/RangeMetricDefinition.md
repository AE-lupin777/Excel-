# RangeMetricDefinition

## 目的

開始イベントから終了イベントまでの区間を対象に、
性能情報を集計する。

---

# 入力

## StartEvent

例

```text
C_START
```

## EndEvent

例

```text
C_END
```

---

# 出力

## CPU

```text
CPU Avg
CPU Max
```

## Memory

```text
Memory Avg
Memory Max
```

## Disk

```text
Disk Read Avg
Disk Read Max

Disk Write Avg
Disk Write Max
```

## Network

```text
Network Send Avg
Network Send Max

Network Receive Avg
Network Receive Max
```

---

# 対象区間例

## Throughput

```text
C_START
↓
C_END
```

意味

```text
送信開始
↓
Receiver受信確認
```

---

## Receiver Processing

```text
G_START
↓
G_END
```

意味

```text
Receiver保存
↓
Receiver受信完了状態
```

---

## Registration

```text
K_START
↓
K_END
```

意味

```text
ULsight登録開始
↓
ULsight登録完了
```

---

## End-to-End

```text
C_START
↓
K_END
```

意味

```text
送信開始
↓
DB登録完了
```
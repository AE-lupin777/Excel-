# ThroughputAnalyzerTool v1.1

## 目的

スループット算出機能追加

## 追加項目

- DurationSec
- FilesPerSec
- MBPerSec

## 課題

ULAgent.Sender.log に複数試験が混在する

## 調査結果

sent差分は取得済み

sample01

SentCount = 3
ReceivedCount = 3
RegisteredCount = 2

## 検討事項

今回試験の開始時刻と終了時刻をどのように特定するか

候補

- Senderログ
- Receiverログ
- execution_info.csv
- records.csv
- status.csv

## 状態

Design

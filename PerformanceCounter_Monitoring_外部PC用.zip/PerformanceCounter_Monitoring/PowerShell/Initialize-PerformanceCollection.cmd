@echo off
setlocal
cd /d "%~dp0"

set "SELFTEST_STATUS=Not run"
set "POWERSHELL_HOST=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "PWSH_HOST="
for /f "delims=" %%I in ('where pwsh.exe 2^>nul') do if not defined PWSH_HOST set "PWSH_HOST=%%I"
if defined PWSH_HOST set "POWERSHELL_HOST=%PWSH_HOST%"

echo PowerShell host: %POWERSHELL_HOST%

echo [1/3] Unblocking PowerShell scripts...
"%POWERSHELL_HOST%" -NoProfile -ExecutionPolicy Bypass -Command ^
  "Get-ChildItem -LiteralPath '%~dp0' -Recurse -Filter *.ps1 -File | Unblock-File"

if errorlevel 1 goto error

echo [2/3] Running setup...
"%POWERSHELL_HOST%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Setup-PerformanceCollection.ps1"

if errorlevel 1 goto error

echo [3/3] Checking whether self-test is required...
"%POWERSHELL_HOST%" -NoProfile -ExecutionPolicy Bypass -Command ^
  "if (Get-Process -Name 'ULAgent.Sender' -ErrorAction SilentlyContinue) { exit 0 } else { exit 10 }"

if errorlevel 11 goto error
if errorlevel 10 goto run_self_test
if errorlevel 1 goto error

set "SELFTEST_STATUS=Skipped (real ULAgent.Sender is running)"
echo [3/3] Real ULAgent.Sender detected. Self-test skipped normally.
goto success

:run_self_test
echo [3/3] ULAgent.Sender not found. Running self-test...
"%POWERSHELL_HOST%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Test-PerformanceCollection.ps1" -KeepArtifacts

if errorlevel 1 goto error
set "SELFTEST_STATUS=Completed"

:success
echo.
echo ========================================
echo Setup completed successfully.
echo Self-test: %SELFTEST_STATUS%
echo ========================================
pause
exit /b 0

:error
echo.
echo ========================================
echo ERROR: Initialization failed.
echo ========================================
pause
exit /b 1

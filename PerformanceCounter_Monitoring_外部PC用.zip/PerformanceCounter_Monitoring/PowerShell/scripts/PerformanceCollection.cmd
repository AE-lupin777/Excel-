@echo off
setlocal

set "PERF_SCRIPT_DIR=%~dp0"
set "POWERSHELL_HOST=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "PWSH_HOST="
for /f "delims=" %%I in ('where pwsh.exe 2^>nul') do if not defined PWSH_HOST set "PWSH_HOST=%%I"
if defined PWSH_HOST set "POWERSHELL_HOST=%PWSH_HOST%"

"%POWERSHELL_HOST%" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Get-ChildItem -LiteralPath $env:PERF_SCRIPT_DIR -Filter '*.ps1' -File | Unblock-File"
if errorlevel 1 exit /b %errorlevel%

if /i "%~1"=="setup" goto setup
if /i "%~1"=="start" goto start
if /i "%~1"=="stop" goto stop
if /i "%~1"=="test" goto test

echo Usage:
echo   PerformanceCollection.cmd setup
echo   PerformanceCollection.cmd start TEST_ID
echo   PerformanceCollection.cmd stop
echo   PerformanceCollection.cmd test [keep]
exit /b 2

:setup
"%POWERSHELL_HOST%" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%PERF_SCRIPT_DIR%Setup-PerformanceCollection.ps1"
exit /b %errorlevel%

:start
if "%~2"=="" (
    echo TEST_ID is required.
    exit /b 2
)
"%POWERSHELL_HOST%" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%PERF_SCRIPT_DIR%Start-PerformanceCollection.ps1" -TestId "%~2"
exit /b %errorlevel%

:stop
"%POWERSHELL_HOST%" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%PERF_SCRIPT_DIR%Stop-PerformanceCollection.ps1"
exit /b %errorlevel%

:test
if /i "%~2"=="keep" (
    "%POWERSHELL_HOST%" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%PERF_SCRIPT_DIR%Test-PerformanceCollection.ps1" -KeepArtifacts
) else (
    "%POWERSHELL_HOST%" -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%PERF_SCRIPT_DIR%Test-PerformanceCollection.ps1"
)
exit /b %errorlevel%

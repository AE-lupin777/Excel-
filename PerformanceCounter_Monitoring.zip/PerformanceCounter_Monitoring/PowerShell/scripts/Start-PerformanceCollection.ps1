param(
    [Parameter(Mandatory = $true)]
    [string]$TestId
)

$ErrorActionPreference = 'Stop'
$SampleInterval = 1

if (-not $TestId -or $TestId.Trim().Length -eq 0) {
    throw 'TestId must not be empty.'
}

if ($TestId.IndexOfAny([System.IO.Path]::GetInvalidFileNameChars()) -ge 0) {
    throw "TestId contains characters that cannot be used in a file name: $TestId"
}

$ProjectRoot = Split-Path -Parent $PSScriptRoot

$CounterFile = Join-Path $ProjectRoot 'config\counters.txt'
$OutputDirectory = Join-Path $ProjectRoot 'output'
$LogDirectory = Join-Path $ProjectRoot 'logs'

$StateFile = Join-Path $LogDirectory 'collection-state.json'

if (-not (Test-Path -Path $CounterFile -PathType Leaf)) {
    throw "Counter file not found: $CounterFile"
}

if (-not (Test-Path -Path $OutputDirectory -PathType Container)) {
    throw "Output directory not found: $OutputDirectory"
}

if (-not (Test-Path -Path $LogDirectory -PathType Container)) {
    throw "Log directory not found: $LogDirectory"
}

if (Test-Path -Path $StateFile -PathType Leaf) {
    throw "Collection state file already exists. Check whether collection is running: $StateFile"
}

$Counters = @(
    Get-Content -Path $CounterFile |
        Where-Object { $_.Trim().Length -gt 0 }
)

if ($Counters.Count -eq 0) {
    throw "No performance counters are defined: $CounterFile"
}

try {
    $ValidationResult = Get-Counter `
        -Counter $Counters `
        -MaxSamples 1 `
        -ErrorAction Stop
}
catch {
    throw "Performance counter validation failed: $($_.Exception.Message)"
}

$ValidatedCounterCount = @($ValidationResult.CounterSamples).Count

if ($ValidatedCounterCount -ne $Counters.Count) {
    throw "Counter count mismatch. Expected: $($Counters.Count), Actual: $ValidatedCounterCount"
}

$StartTime = Get-Date
$Timestamp = $StartTime.ToString('yyyyMMdd_HHmmss')

$BlgFileName = "${TestId}_${Timestamp}.blg"
$BlgPath = Join-Path $OutputDirectory $BlgFileName

$LogFileName = "${TestId}_${Timestamp}.log"
$LogPath = Join-Path $LogDirectory $LogFileName

if (Test-Path -Path $BlgPath) {
    throw "BLG file already exists: $BlgPath"
}

$JobName = "PerfCollection_$Timestamp"

$Job = Start-Job `
    -Name $JobName `
    -ArgumentList $CounterFile, $BlgPath, $SampleInterval `
    -ScriptBlock {
        param(
            [string]$CounterFilePath,
            [string]$OutputPath,
            [int]$Interval
        )

        $JobCounters = @(
            Get-Content -Path $CounterFilePath |
                Where-Object { $_.Trim().Length -gt 0 }
        )

        Get-Counter `
            -Counter $JobCounters `
            -SampleInterval $Interval `
            -Continuous |
            Export-Counter `
                -Path $OutputPath `
                -FileFormat BLG
    }

$State = [PSCustomObject]@{
    TestId         = $TestId
    JobId          = $Job.Id
    JobName        = $Job.Name
    StartTime      = $StartTime.ToString('yyyy-MM-dd HH:mm:ss')
    SampleInterval = $SampleInterval
    CounterCount   = $Counters.Count
    BlgPath        = $BlgPath
    LogPath        = $LogPath
}

$State |
    ConvertTo-Json |
    Set-Content -Path $StateFile -Encoding UTF8

@(
    "Result=Started"
    "TestId=$TestId"
    "StartTime=$($State.StartTime)"
    "JobId=$($Job.Id)"
    "JobName=$($Job.Name)"
    "SampleInterval=$SampleInterval"
    "CounterCount=$($Counters.Count)"
    "BlgPath=$BlgPath"
) | Set-Content -Path $LogPath -Encoding UTF8

Start-Sleep -Seconds 2

$CurrentJob = Get-Job -Id $Job.Id

[PSCustomObject]@{
    Result         = 'Started'
    TestId         = $TestId
    JobId          = $CurrentJob.Id
    JobState       = $CurrentJob.State
    CounterCount   = $Counters.Count
    SampleInterval = $SampleInterval
    BlgPath        = $BlgPath
    StateFile      = $StateFile
    LogPath        = $LogPath
}
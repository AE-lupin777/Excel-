param(
    [Parameter(Mandatory = $true)]
    [string]$BlgPath
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path -Path $BlgPath -PathType Leaf)) {
    throw "BLG file not found: $BlgPath"
}

$CsvPath = [System.IO.Path]::ChangeExtension($BlgPath, '.csv')

if (Test-Path -Path $CsvPath) {
    throw "CSV file already exists: $CsvPath"
}

try {
    Import-Counter -Path $BlgPath |
        Export-Counter -Path $CsvPath -FileFormat CSV
}
catch {
    throw "BLG to CSV conversion failed: $($_.Exception.Message)"
}

$CsvData = @(Import-Csv -Path $CsvPath)

if ($CsvData.Count -eq 0) {
    throw "Converted CSV contains no data rows: $CsvPath"
}

$ColumnCount = @($CsvData[0].PSObject.Properties).Count

[PSCustomObject]@{
    Result      = 'Converted'
    BlgPath     = $BlgPath
    CsvPath     = $CsvPath
    DataRows    = $CsvData.Count
    ColumnCount = $ColumnCount
}
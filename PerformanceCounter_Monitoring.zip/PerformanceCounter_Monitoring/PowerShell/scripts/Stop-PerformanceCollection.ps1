$ErrorActionPreference = 'Stop'

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$LogDirectory = Join-Path $ProjectRoot 'logs'
$StateFile = Join-Path $LogDirectory 'collection-state.json'
$ConvertScript = Join-Path $PSScriptRoot 'Convert-PerformanceLog.ps1'

if (-not (Test-Path -Path $StateFile -PathType Leaf)) {
    throw "Collection state file not found: $StateFile"
}

if (-not (Test-Path -Path $ConvertScript -PathType Leaf)) {
    throw "Conversion script not found: $ConvertScript"
}

$State = Get-Content -Path $StateFile -Raw |
    ConvertFrom-Json

$Job = Get-Job -Id $State.JobId -ErrorAction SilentlyContinue

if ($null -eq $Job) {
    throw "Collection job not found in the current PowerShell session. JobId: $($State.JobId)"
}

if ($Job.State -eq 'Running') {
    Stop-Job -Id $Job.Id
}

Wait-Job -Id $Job.Id | Out-Null

Receive-Job -Id $Job.Id -ErrorAction SilentlyContinue |
    Out-Null

Remove-Job -Id $Job.Id

Start-Sleep -Seconds 2

if (-not (Test-Path -Path $State.BlgPath -PathType Leaf)) {
    throw "BLG file was not created: $($State.BlgPath)"
}

$Summary = Import-Counter -Path $State.BlgPath -Summary

$CounterCount = @(
    (Import-Counter -Path $State.BlgPath -MaxSamples 1).CounterSamples
).Count

if ($CounterCount -ne $State.CounterCount) {
    throw "Counter count mismatch. Expected: $($State.CounterCount), Actual: $CounterCount"
}

$ConversionResult = & $ConvertScript -BlgPath $State.BlgPath

$StopTime = Get-Date

@(
    "StopTime=$($StopTime.ToString('yyyy-MM-dd HH:mm:ss'))"
    "Result=Stopped"
    "SampleCount=$($Summary.SampleCount)"
    "CounterCount=$CounterCount"
    "CsvPath=$($ConversionResult.CsvPath)"
) | Add-Content -Path $State.LogPath -Encoding UTF8

Remove-Item -Path $StateFile

[PSCustomObject]@{
    Result       = 'Stopped'
    TestId       = $State.TestId
    StartTime    = $State.StartTime
    StopTime     = $StopTime.ToString('yyyy-MM-dd HH:mm:ss')
    SampleCount  = $Summary.SampleCount
    CounterCount = $CounterCount
    BlgPath      = $State.BlgPath
    CsvPath      = $ConversionResult.CsvPath
    DataRows     = $ConversionResult.DataRows
    ColumnCount  = $ConversionResult.ColumnCount
    LogPath      = $State.LogPath
}
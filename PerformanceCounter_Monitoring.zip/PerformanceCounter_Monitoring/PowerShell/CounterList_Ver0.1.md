# Performance Counter収集対象一覧 Ver.0.1

## 1. 文書情報

- 文書名：Performance Counter収集対象一覧
- バージョン：Ver.0.1
- 作成日：2026/09/08
- 作成目的：ULAgent総合試験に向けた収集対象候補の整理
- 作成環境：一般Windows環境
- 状態：リーダーレビュー前の仕様案

---

## 2. 目的

ULAgent総合試験において、CTC側IPCのシステムリソースおよび
ULAgent関連プロセスのリソース使用状況を測定する。

本一覧では、以下の収集対象候補を整理する。

- システム全体のCPU
- システム全体のMemory
- PhysicalDisk I/O
- Network I/O
- 対象プロセスのCPU
- 対象プロセスのMemory
- 対象プロセスのI/O
- 対象プロセスの識別情報

本一覧では性能クライテリアを決定しない。

---

## 3. 優先度の定義

### 必須候補

ULAgent総合試験における基本的なリソース使用状況の確認に必要と考えるカウンター。

### 推奨候補

必須候補を補足し、ボトルネックやリソース使用状況を詳しく確認するためのカウンター。

### 識別用候補

性能値ではなく、測定対象の識別および測定結果の妥当性確認に使用するカウンター。

正式な優先度はリーダーレビュー後に決定する。

---

## 4. 収集対象カウンター一覧

| No. | 分類 | 優先度案 | カウンターパス | 単位 | 用途 | 模擬環境での確認 |
|---:|---|---|---|---|---|---|
| 1 | System CPU | 必須候補 | `\Processor(_Total)\% Processor Time` | Percent | IPC全体のCPU使用率を確認する | 取得成功 |
| 2 | System Memory | 必須候補 | `\Memory\Available Bytes` | Bytes | Windowsが利用可能と判断している物理メモリ容量を確認する | 取得成功 |
| 3 | PhysicalDisk | 必須候補 | `\PhysicalDisk(_Total)\Disk Read Bytes/sec` | Bytes/sec | 全物理ディスクの読み取り量を確認する | 取得成功 |
| 4 | PhysicalDisk | 必須候補 | `\PhysicalDisk(_Total)\Disk Write Bytes/sec` | Bytes/sec | 全物理ディスクの書き込み量を確認する | 取得成功 |
| 5 | PhysicalDisk | 推奨候補 | `\PhysicalDisk(_Total)\Disk Transfers/sec` | Transfers/sec | 読み取りと書き込みを合わせたI/O回数を確認する | 取得成功 |
| 6 | PhysicalDisk | 推奨候補 | `\PhysicalDisk(_Total)\Avg. Disk Queue Length` | Requests | 処理中または処理待ちのディスク要求数を確認する | 取得成功 |
| 7 | Network | 必須候補 | `\Network Interface(<対象NIC>)\Bytes Received/sec` | Bytes/sec | 対象NICの受信量を確認する | 取得成功 |
| 8 | Network | 必須候補 | `\Network Interface(<対象NIC>)\Bytes Sent/sec` | Bytes/sec | 対象NICの送信量を確認する | 取得成功 |
| 9 | Process CPU | 必須候補 | `\Process(<対象プロセス>)\% Processor Time` | Percent | 対象プロセスのCPU使用率を確認する | 取得成功 |
| 10 | Process Memory | 必須候補 | `\Process(<対象プロセス>)\Working Set - Private` | Bytes | 対象プロセス固有の物理メモリ使用量を確認する | 取得成功 |
| 11 | Process Memory | 推奨候補 | `\Process(<対象プロセス>)\Private Bytes` | Bytes | 対象プロセスが確保したプライベートメモリ領域を確認する | 取得成功 |
| 12 | Process I/O | 必須候補 | `\Process(<対象プロセス>)\IO Read Bytes/sec` | Bytes/sec | 対象プロセスの読み取りI/O量を確認する | 取得成功 |
| 13 | Process I/O | 必須候補 | `\Process(<対象プロセス>)\IO Write Bytes/sec` | Bytes/sec | 対象プロセスの書き込みI/O量を確認する | 取得成功 |
| 14 | Process識別 | 識別用候補 | `\Process(<対象プロセス>)\ID Process` | PID | Performance CounterインスタンスとPIDを対応付ける | 取得成功 |

---

## 5. 模擬環境で使用したインスタンス

### 対象PC

```text
valtes1072
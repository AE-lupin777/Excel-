# PerformanceCounter MonitoringTool 取扱説明書

## Windows 性能情報収集ツール

| 項目 | 内容 |
|---|---|
| 対象ツール | PerformanceCounter MonitoringTool |
| 対象フォルダ | `\PerformanceCounter_MonitoringTool` |
| 対象 | ULAgent SenderまたはReceiverの性能試験 |

## 目次

1. [ツールの目的](#1-ツールの目的)
2. [動作環境と事前準備](#2-動作環境と事前準備)
3. [フォルダと主要ファイル](#3-フォルダと主要ファイル)
4. [SenderとReceiverの選択](#4-senderとreceiverの選択)
5. [初期化](#5-初期化)
6. [収集開始](#6-収集開始)
7. [収集停止](#7-収集停止)
8. [CollectorHostの終了](#8-collectorhostの終了)
9. [推奨する運用手順](#9-推奨する運用手順)
10. [出力ファイル](#10-出力ファイル)
11. [正常終了の確認](#11-正常終了の確認)
12. [エラー時の確認](#12-エラー時の確認)
13. [使用上の注意](#13-使用上の注意)

---

## 1 ツールの目的

本ツールは、ULAgentの性能試験中に、Windows PCのCPU、メモリ、ディスク、ネットワーク使用量を収集します。

収集結果は、WindowsのPerformance Counter形式であるBLGファイルと、Excelなどで確認できるCSVファイルへ保存されます。

### 主な機能

- PC全体のCPU使用率を収集する
- ULAgentプロセスのCPU使用率とメモリ使用量を収集する
- ディスクの読み書き量を収集する
- ディスクキュー長を収集する
- ネットワークの送受信量を収集する
- 収集結果をBLGとCSVで保存する
- 収集結果の行数と列数を確認する

### 用語

| 用語 | 説明 |
|---|---|
| Performance Counter | Windowsが提供するCPU、メモリ、ディスクなどの性能測定機能です。 |
| BLG | Performance Counterの測定値を保存するWindows標準のバイナリ形式です。 |
| CSV | 測定結果を表形式で保存したファイルです。Excelなどで確認できます。 |
| CollectorHost | バックグラウンドで待機し、性能情報を収集するPowerShellプロセスです。 |
| Sender | ULAgentでファイルを送信する側です。 |
| Receiver | ULAgentでファイルを受信する側です。 |

## 2 動作環境と事前準備

### 2.1 動作環境

| 項目 | 内容 |
|---|---|
| OS | Windows |
| PowerShell | Windows PowerShell 5.1 |
| 配置場所 | 性能情報を収集するSenderまたはReceiverと同じPC |
| 実行権限 | 管理者としての実行を推奨 |

本ツールは、Windows標準のPerformance Counter機能を使用します。

### 2.2 配置

ツール一式を、性能情報を収集するPCへ配置します。

Senderの性能を測定する場合はSenderが動作するPC、Receiverの性能を測定する場合はReceiverが動作するPCへ配置してください。

### 2.3 実行画面を開く

1. Windowsのスタートメニューを開きます。
2. `Windows PowerShell` または `コマンドプロンプト` を検索します。
3. 必要に応じて右クリックし、`管理者として実行` を選びます。
4. 次のコマンドでツールのフォルダへ移動します。

```cmd
cd /d \PerformanceCounter_MonitoringTool
```

PowerShellを使用する場合は、次のコマンドでも移動できます。

```powershell
Set-Location "\PerformanceCounter_MonitoringTool"
```

## 3 フォルダと主要ファイル

```text
PerformanceCounter_MonitoringTool
├─ Initialize-PerformanceCollection.cmd
├─ README.md
├─ config
│  ├─ counters.txt
│  └─ role.conf
└─ scripts
   ├─ CollectorHost.ps1
   ├─ Convert-PerformanceLog.ps1
   ├─ HostCommon.ps1
   ├─ PerformanceCollection.cmd
   ├─ Setup-PerformanceCollection.ps1
   ├─ Start-CollectorHost.ps1
   ├─ Start-PerformanceCollection.ps1
   ├─ Stop-CollectorHost.ps1
   └─ Stop-PerformanceCollection.ps1
```

初期化または収集を実行すると、次のフォルダやファイルが作成されます。

```text
PerformanceCounter_MonitoringTool
├─ config
│  └─ counters.effective.txt
├─ logs
└─ output
```

### 主要ファイルの役割

| ファイル | 役割 |
|---|---|
| `Initialize-PerformanceCollection.cmd` | SenderまたはReceiverを選び、収集機能を初期化します。 |
| `config\role.conf` | 選択した役割を保存します。 |
| `config\counters.txt` | 収集対象となる性能項目を定義します。 |
| `config\counters.effective.txt` | 対象PCで実際に使用できる性能項目を保存します。 |
| `scripts\PerformanceCollection.cmd` | 収集開始、収集停止、CollectorHost終了の操作に使用します。 |
| `scripts\Start-PerformanceCollection.ps1` | 性能情報の収集を開始します。 |
| `scripts\Stop-PerformanceCollection.ps1` | 収集を停止し、CSV作成と結果確認を行います。 |
| `scripts\CollectorHost.ps1` | バックグラウンドで性能情報を収集します。 |
| `scripts\Convert-PerformanceLog.ps1` | BLGファイルをCSVファイルへ変換します。 |

利用者が通常操作するファイルは、次の2つです。

- `Initialize-PerformanceCollection.cmd`
- `scripts\PerformanceCollection.cmd`

その他のPowerShellファイルは、通常は直接実行しないでください。

## 4 SenderとReceiverの選択

初期化時に、測定対象をSenderまたはReceiverから選びます。

| 選択 | 測定対象プロセス | 初期化時の指定 |
|---|---|---|
| Sender | `ULAgent.Sender` | `sender` |
| Receiver | `ULAgent.Receiver` | `receiver` |

選択結果は、次のファイルへ保存されます。

```text
config\role.conf
```

### 収集する性能情報

- PC全体のCPU使用率
- 使用可能メモリ
- ディスク読み込み量
- ディスク書き込み量
- ディスク転送回数
- 平均ディスクキュー長
- ネットワーク受信量
- ネットワーク送信量
- ULAgentプロセスのCPU使用率
- ULAgentプロセスのメモリ使用量
- ULAgentプロセスの入出力量
- ULAgentプロセスのプロセスID

初期化時に、対象PCで取得できない性能項目は除外されます。実際に使用される性能項目は、次のファイルで確認できます。

```text
config\counters.effective.txt
```

## 5 初期化

初期化は、試験を始める前に実行します。

初期化すると、収集項目の確認とCollectorHostの起動が行われます。

### 5.1 Sender側の初期化

```cmd
Initialize-PerformanceCollection.cmd sender
```

### 5.2 Receiver側の初期化

```cmd
Initialize-PerformanceCollection.cmd receiver
```

### 5.3 初期化で行われる処理

1. SenderまたはReceiverの役割を保存します。
2. `logs` フォルダを作成します。
3. `output` フォルダを作成します。
4. 対象PCで使用できるPerformance Counterを確認します。
5. 使用できる性能項目を `counters.effective.txt` へ保存します。
6. CollectorHostをバックグラウンドで起動します。

### 5.4 初期化完了の確認

次の表示を確認します。

```text
Result : Ready
```

CollectorHostの表示は、初回と2回目以降で異なる場合があります。

```text
CollectorHostResult : Started
```

または

```text
CollectorHostResult : AlreadyRunning
```

どちらの場合も、`Result : Ready` が表示されていれば収集開始の準備ができています。

## 6 収集開始

### 6.1 開始前の確認

1. 第5章の初期化が完了していることを確認します。
2. SenderまたはReceiverが起動していることを確認します。
3. 試験IDを確認します。
4. 前回の収集が停止済みであることを確認します。

### 6.2 開始コマンド

```cmd
scripts\PerformanceCollection.cmd start TEST_001
```

`TEST_001` の部分を、実際の試験IDへ置き換えます。

例：

```cmd
scripts\PerformanceCollection.cmd start 1-1-1_SENDER
```

### 6.3 試験IDの入力ルール

試験IDは出力ファイル名に使用されます。

半角英数字、ハイフン、アンダースコアの使用を推奨します。

次の文字は使用できません。

```text
\ / : * ? " < > |
```

### 6.4 収集開始の確認

次の表示を確認します。

```text
Result          : Started
LifecycleStatus : Running
```

`Started` が表示された時点で、最初の性能情報が取得されています。

通常の収集間隔は1秒です。

収集開始を確認した後、ULAgentの試験を開始してください。

## 7 収集停止

ULAgentの試験が終了したら、次のコマンドを実行します。

```cmd
scripts\PerformanceCollection.cmd stop
```

### 7.1 停止時に行われる処理

1. Performance Counterの収集を停止します。
2. BLGファイルが作成されていることを確認します。
3. BLGファイルをCSVファイルへ変換します。
4. BLGのサンプル数とCSVのデータ行数を比較します。
5. 性能項目数とCSVの列数を比較します。
6. 正常終了した収集状態を保存します。

### 7.2 収集停止の確認

次の表示を確認します。

```text
Result          : Stopped
LifecycleStatus : CompletedValidated
```

`CompletedValidated` は、収集停止、CSV変換、出力内容の確認が完了したことを表します。

停止処理が完了するまで、コマンド画面を閉じないでください。

## 8 CollectorHostの終了

CollectorHostは、複数回の試験で再利用できます。試験ごとに終了する必要はありません。

すべての試験が終了した後に、次のコマンドを1回実行します。

```cmd
scripts\PerformanceCollection.cmd shutdown
```

### 8.1 終了の確認

```text
Result : Stopped
```

CollectorHostがすでに停止している場合は、次のように表示されます。

```text
Result : NotRunning
```

### 8.2 shutdownできない場合

収集中はCollectorHostを終了できません。

先に次のコマンドで収集を停止してください。

```cmd
scripts\PerformanceCollection.cmd stop
```

`CompletedValidated` を確認した後、もう一度 `shutdown` を実行します。

## 9 推奨する運用手順

### 9.1 1回だけ試験する場合

```text
初期化
  ↓
収集開始
  ↓
ULAgentの試験
  ↓
収集停止
  ↓
出力確認
  ↓
CollectorHost終了
```

コマンド例：

```cmd
Initialize-PerformanceCollection.cmd sender
scripts\PerformanceCollection.cmd start TEST_001
scripts\PerformanceCollection.cmd stop
scripts\PerformanceCollection.cmd shutdown
```

### 9.2 複数回試験する場合

```text
初期化
  ↓
収集開始 → 試験 → 収集停止
  ↓
収集開始 → 試験 → 収集停止
  ↓
必要回数繰り返す
  ↓
CollectorHost終了
```

コマンド例：

```cmd
Initialize-PerformanceCollection.cmd receiver

scripts\PerformanceCollection.cmd start TEST_001
scripts\PerformanceCollection.cmd stop

scripts\PerformanceCollection.cmd start TEST_002
scripts\PerformanceCollection.cmd stop

scripts\PerformanceCollection.cmd shutdown
```

試験IDは試験ごとに変えてください。

## 10 出力ファイル

### 10.1 性能データ

収集結果は、次のフォルダへ保存されます。

```text
output
```

ファイル名は次の形式です。

```text
テストID_yyyyMMdd_HHmmss_RunId.blg
テストID_yyyyMMdd_HHmmss_RunId.csv
```

| ファイル | 内容 |
|---|---|
| `.blg` | Performance Counterの元データです。 |
| `.csv` | BLGを表形式へ変換したデータです。 |

CSVの日時はUTCで保存されます。

```text
yyyy-MM-ddTHH:mm:ss.fff+00:00
```

日本時間との時差は9時間です。

### 10.2 実行ログと状態ファイル

ログと状態情報は、次のフォルダへ保存されます。

```text
logs
```

主なファイルは次のとおりです。

| ファイル | 内容 |
|---|---|
| `collector-host.json` | 動作中のCollectorHostの情報です。 |
| `collector-host.ready` | CollectorHostが待機できる状態であることを示します。 |
| `collection-state.json` | 現在収集中の試験情報です。正常停止後に削除されます。 |
| `テストID_日時_RunId.log` | 収集開始、停止、件数、出力先などの実行記録です。 |
| `collector-run-RunId.final.json` | 収集の最終結果です。 |
| `collector-host.stderr.log` | CollectorHostで発生したエラーの記録です。 |
| `collector-host.error.log` | CollectorHostの詳細なエラー記録です。 |

異常終了した場合は、調査のため状態ファイルが残ることがあります。

## 11 正常終了の確認

### 11.1 初期化後

- `Result : Ready` が表示されている
- `config\counters.effective.txt` が作成されている
- `logs\collector-host.json` が作成されている
- `logs\collector-host.ready` が作成されている

### 11.2 収集開始後

- `Result : Started` が表示されている
- `LifecycleStatus : Running` が表示されている
- `logs\collection-state.json` が作成されている
- `output` にBLGファイルが作成されている

### 11.3 収集停止後

- `Result : Stopped` が表示されている
- `LifecycleStatus : CompletedValidated` が表示されている
- 同じ名前のBLGファイルとCSVファイルがある
- CSVファイルにヘッダーとデータ行がある
- `collection-state.json` が削除されている

### 11.4 全試験終了後

- `shutdown` の結果が `Stopped` または `NotRunning` になっている
- `collector-host.json` が削除されている
- CollectorHostの最終状態ファイルが作成されている

## 12 エラー時の確認

### 12.1 よくあるエラー

| 表示または症状 | 対応 |
|---|---|
| `Usage: Initialize-PerformanceCollection.cmd sender | receiver` | `sender` または `receiver` を指定して初期化します。 |
| `TEST_ID is required.` | `start` の後に試験IDを指定します。 |
| `Invalid TestId` | 試験IDから使用できない記号を取り除きます。 |
| `Role file not found` | `Initialize-PerformanceCollection.cmd` を先に実行します。 |
| `Invalid role in role.conf` | SenderまたはReceiverを指定して、もう一度初期化します。 |
| `Counter file not found` | 初期化をやり直し、`counters.effective.txt` を確認します。 |
| `No effective counters were found.` | 対象PCで使用できるPerformance Counterを確認します。 |
| `Collection state already exists` | すでに収集中か、前回の異常状態が残っています。状態ファイルを削除せず、ログを確認します。 |
| `Timed out while waiting for the first counter sample.` | ULAgentプロセスとPerformance Counterの状態を確認します。 |
| `Collection state file not found` | 収集開始前、またはすでに停止済みです。 |
| `StopTimeout` | CollectorHostが停止処理を完了できていません。ログを保存して管理者へ連絡します。 |
| `OutputValidationFailed` | BLGまたはCSVの内容確認に失敗しています。該当ファイルとログを保存します。 |

### 12.2 エラー発生時に保存するもの

エラーが発生した場合は、次の情報を削除せずに保存してください。

- `logs` フォルダ全体
- `output` フォルダ内の該当BLGとCSV
- コマンド画面に表示されたエラーメッセージ
- 実行したコマンド
- 使用した試験ID
- SenderとReceiverのどちらで実行したか

### 12.3 状態ファイルは手動削除しない

次のファイルは、CollectorHostと収集処理の状態確認に使用されます。

```text
logs\collector-host.json
logs\collection-state.json
```

エラー時に手動削除すると、実行中の処理と状態情報の対応が分からなくなる可能性があります。削除せず、ツール管理者へ連絡してください。

## 13 使用上の注意

1. SenderとReceiverを間違えないよう、初期化コマンドを確認してください。
2. 初期化は試験開始前に実行してください。
3. 収集開始後にULAgentの試験を開始してください。
4. 試験終了後は必ず `stop` を実行してください。
5. `CompletedValidated` を確認してから出力ファイルを使用してください。
6. CollectorHostは試験ごとに終了せず、すべての試験終了後に `shutdown` してください。
7. 収集中にCollectorHostをタスクマネージャーなどから終了しないでください。
8. `logs` と `output` を別PCからコピーして混在させないでください。
9. 状態ファイルを手動で編集または削除しないでください。
10. `config\counters.txt` を変更する場合は、変更前のファイルを保存してください。
11. スリープ、ログオフ、PC再起動を行う前に収集を停止してください。
12. 長時間収集を行う場合は、事前に短時間の試験で動作と空き容量を確認してください。
13. CSVをExcelで確認するときは、日時がUTCであることに注意してください。

---

## 操作コマンド一覧

### Sender初期化

```cmd
Initialize-PerformanceCollection.cmd sender
```

### Receiver初期化

```cmd
Initialize-PerformanceCollection.cmd receiver
```

### 収集開始

```cmd
scripts\PerformanceCollection.cmd start TEST_ID
```

### 収集停止

```cmd
scripts\PerformanceCollection.cmd stop
```

### CollectorHost終了

```cmd
scripts\PerformanceCollection.cmd shutdown
```
